<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
/**
 * InvoiceDetails Controller
 *
 * @property \App\Model\Table\InvoiceDetailsTable $InvoiceDetails
 *
 * @method \App\Model\Entity\InvoiceDetail[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class InvoiceDetailsController extends AppController
{

    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        $this->viewBuilder()->setLayout('adminlayout');
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Users', 'Properties']
        ];
        $invoiceDetails = $this->paginate($this->InvoiceDetails);

        $this->set(compact('invoiceDetails'));
        $this->set('title', 'Invoices');
    }

    /**
     * View method
     *
     * @param string|null $id Invoice Detail id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $invoiceDetail = $this->InvoiceDetails->get($id, [
            'contain' => ['Users', 'Properties']
        ]);

        $this->set('invoiceDetail', $invoiceDetail);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add($t_id = null, $p_id = null)
    {
        $invoiceDetail = $this->InvoiceDetails->newEntity();
        if ($this->request->is('post')) {
            $invoiceDetail = $this->InvoiceDetails->patchEntity($invoiceDetail, $this->request->getData());
            $invoiceDetail->property_id = $p_id;
            $invoiceDetail->tenant_id = $t_id;
            $invoiceDetail->status = 0;
            // pr($invoiceDetail->toArray());die;
            if ($this->InvoiceDetails->save($invoiceDetail)) {
                $this->Flash->success(__('The invoice detail has been saved.'));

                return $this->redirect(['action' => 'index']);
            }   else   {
                $this->Flash->error(__('The invoice detail could not be saved. Please, try again.'));
            }
        }
        // $users = $this->InvoiceDetails->Users->find('list', ['limit' => 200]);
        // $properties = $this->InvoiceDetails->Properties->find('list', ['limit' => 200]);
        $this->set(compact('invoiceDetail'));
        $this->set('title' , 'Add Invoice Details');
    }

    /**
     * Edit method
     *
     * @param string|null $id Invoice Detail id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $invoiceDetail = $this->InvoiceDetails->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $invoiceDetail = $this->InvoiceDetails->patchEntity($invoiceDetail, $this->request->getData());
            if ($this->InvoiceDetails->save($invoiceDetail)) {
                $this->Flash->success(__('The invoice detail has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The invoice detail could not be saved. Please, try again.'));
        }
        $users = $this->InvoiceDetails->Users->find('list', ['limit' => 200]);
        $properties = $this->InvoiceDetails->Properties->find('list', ['limit' => 200]);
        $this->set(compact('invoiceDetail', 'users', 'properties'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Invoice Detail id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $invoiceDetail = $this->InvoiceDetails->get($id);
        if ($this->InvoiceDetails->delete($invoiceDetail)) {
            $this->Flash->success(__('The invoice detail has been deleted.'));
        } else {
            $this->Flash->error(__('The invoice detail could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
    public function viewInvoice($id = null) {
        $this->loadModel('Users');
        $invoiceDetail = $this->InvoiceDetails->get($id, [
            'contain' => ['Users', 'Properties']
        ]);
        $invoice_no = $invoiceDetail->id;
        $due_date = $invoiceDetail->due_date;
        $created_date = $invoiceDetail->created_date;
        $total_amount = $invoiceDetail->total_amount;
        
        $pro_ref = $invoiceDetail->property['refrence'];
        $pro_address = $invoiceDetail->property['address'];
        $o_id = $invoiceDetail->property['user_id'];
        $owner_username = $this->Users->get($o_id)->username;
        // pr($pro_address);die;
        $t_id = $invoiceDetail->tenant_id;
        $t_detail = $this->Users->get($t_id, [
        'contain' => 'TenantDetails'
        ]);
        $t_username = $t_detail->username;
        
        foreach($t_detail->tenant_details as $values) {
            $t_firstname = $values->first_name;
            $t_lastname = $values->last_name;
            $t_contact = $values->contact_no;
        }
        
        $this->set('due_date', $due_date);
        $this->set('created_date', $created_date);

        $this->set('total_amount', $total_amount);
        $this->set('pro_ref', $pro_ref);

        $this->set('pro_address', $pro_address);
        $this->set('owner_username', $owner_username);
        
        $this->set('t_username', $t_username);
        $this->set('invoice_no', $invoice_no);

        $this->viewBuilder()->setLayout('homepage');
        $this->set('title', 'View Invoice');
    }
}
