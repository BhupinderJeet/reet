<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
// use\Cake\Mailer\Email;
/**
 * Inspections Controller
 *
 * @property \App\Model\Table\InspectionsTable $Inspections
 *
 * @method \App\Model\Entity\Inspection[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class InspectionsController extends AppController
{
    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        $this->viewBuilder()->setLayout('adminlayout');
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Properties']
        ];
        $inspections = $this->paginate($this->Inspections);
        //pr($inspections);
        $this->set(compact('inspections'));
        $this->set('title', 'All Inspections');
    }

    /**
     * View method
     *
     * @param string|null $id Inspection id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null) {
        $inspection = $this->Inspections->get($id, [
            'contain' => ['Properties']
        ]);

        $this->set('inspection', $inspection);
        $this->set('title', 'Inspection Details');
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add($pro_id = null) {   
        $this->loadModel('Properties');
        $this->loadModel('Users');
        $this->loadModel('Inspections');
        $entry = "";
        $this->set('entry',$entry);
        $prop = $this->Properties->find('all')->toArray();
        //pr($prop);
        $proper = array();
        foreach ($prop as $key => $value) {
                $proper[$value->id] = $value->refrence;
        }

        $staff_id = $this->Users->find('all',[
                    'conditions' => ['group_id' => 11]
                ])->toArray();
        //pr($staff);
        $staff = array();
        foreach ($staff_id as $key => $value) {
            $staff[$value->id] = $value->username;
        }
        //pr($staff);
        $entry = $this->Inspections->newEntity();
        if ($this->request->is('post')) {
            $entry = $this->Inspections->patchEntity($entry, $this->request->getData());

            //$entry->ins_type = "entry";
            $entry->status = "Scheduled";

             $page= $entry->toArray();
             $page_name = $page['ins_type'].'_index';
            if ($this->Inspections->save($entry)) {
                $this->Flash->success(__('The inspection has been saved.'));
                // $email = new Email('default');
                // $email->from(['taskreport1@gmail.com' => 'McCarthysrealestate'])
                //     ->to('r4nifty@gmail.com')
                //     ->subject('You are now tenant...')
                //     ->send('My message. You are assigned with demo property.');
                // pr($email);die;

                return $this->redirect(['action' => $page_name]);
            }   else   {
                pr($entry->errors());
                $this->Flash->error(__('The inspection could not be saved. Please, try again.'));
            }
            
        }
       $status = ['Active' => 'Active', 'Scheduled' => 'Scheduled', 'Inspected' => 'Inspected', 'Unscheduled' => 'Unscheduled', 'Closed' => 'Closed'];
       $type = ['entry' => 'Entry' , 'routine' => 'Routine' , 'exit' => 'Exit'];
        $this->set(compact(['proper', 'status' ,'staff' , 'type']));
        $this->set('title', 'Add Entry Inspection');
    }
    



    public function openInspections() {
        $this->loadModel('Properties');
        $this->loadModel('OpenInspections');
        $open = "";
        $this->set('open',$open);
        
        $prop = $this->Properties->find('all')->toArray();
        //pr($prop);
        $proper = array();
        foreach ($prop as $key => $value) {
                $proper[$value->id] = $value->refrence;
        }
                $open = $this->OpenInspections->newEntity();
        if ($this->request->is('post')) {
            $open = $this->OpenInspections->patchEntity($open, $this->request->getData());

            //$inspection->property_id = $pro_id;
            //$inspection->created_by = $uid;

            // pr($inspection->toArray());die;
            if ($this->OpenInspections->save($open)) {
                $this->Flash->success(__('The inspection has been saved.'));
                // $email = new Email('default');
                // $email->from(['taskreport1@gmail.com' => 'McCarthysrealestate'])
                //     ->to('r4nifty@gmail.com')
                //     ->subject('You are now tenant...')
                //     ->send('My message. You are assigned with demo property.');
                // pr($email);die;
                return $this->redirect(['action' => 'open_index']);
            }   else   {
                pr($open->errors());
                $this->Flash->error(__('The inspection could not be saved. Please, try again.'));
            }
            
        }
        //pr($proper);
        $status = ['Active' => 'Active', 'Scheduled' => 'Scheduled', 'Inspected' => 'Inspected', 'Unscheduled' => 'Unscheduled', 'Closed' => 'Closed'];
        $this->set(compact(['proper', 'status']));
        $this->set('title', 'Add Open Inspection');

    }
    public function openIndex() {
        $this->loadModel('OpenInspections');
        $this->loadModel('Properties');
        $openins = $this->OpenInspections->find('all')->toArray();
       
        foreach ($openins as $key => $value) {
            $propname = $this->Properties->find('all',[
                    'conditions' => ['id' => $value->property_id]
                ])->toArray();
            $openins[$key] = $value->toArray();
            $prop_name = $propname[0]->refrence;
            array_push($openins[$key] ,$prop_name);
        }
         $this->set(compact(['openins']));
        $this->set('title', 'Open Inspections');
        //pr($openins);
    }
    public function entryInspections($id = null) {
        $this->loadModel('Properties');
        $this->loadModel('Users');
        $this->loadModel('Inspections');
        $this->loadModel('EntryInspections');
        $this->loadModel('EntryImages');
        $entry = "";
        $this->set('entry',$entry);
        $entry_i = $this->Inspections->find('all',[
                'conditions' => ['id'=> $id]
            ])->toArray();
        //pr($entry_i);die;
        foreach ($entry_i as $key => $value) {
            $prop = $this->Properties->find('all',[
                    'conditions' => ['id' => $value->property_id]
                ])->toArray();
            $staff = $this->Users->find('all',[
                    'conditions' => ['id'=>$value->staff_id]
                ])->toArray();
            $entry_i[$key]= $value->toArray();
            $prop_name = $prop[0]->refrence;
            $staff_name = $staff[0]->username;
            //echo $key;
            array_push($entry_i[$key] ,$prop_name);
            array_push($entry_i[$key] ,$staff_name);
        }

            $inspimg = $this->EntryInspections->newEntity();
            $inimg = $this->EntryImages->newEntity();
            if($this->request->is('post')){
                $pro_imgs_all = $this->request->getData();
                    foreach($pro_imgs_all['img'] as $proimg){
                        //pr($proimg);
                        //die;
                        $target_dir = "img/inspections/";
                        $target_file = $target_dir . basename($proimg['fimg']['name']);
                        $filename = $proimg['fimg']['name'];
                        $tempName = $proimg['fimg']['tmp_name'];
                        move_uploaded_file($tempName, $target_file);
                        $inimg = $this->EntryImages->patchEntity($inimg,$this->request->getData());
                        $inimg->entry_id = $id;
                        $inimg->imagename = $filename;
                        if($this->EntryImages->save($inimg)){
                            //pr($inimg->errors());
                        }else{
                           pr($inimg->errors()); 
                        }
                    }
            $inspimg = $this->EntryInspections->patchEntity($inspimg, $this->request->getData());            
            $inspimg->ins_id = $id;
            if($this->EntryInspections->save($inspimg)){
                //echo "hellll";
                $this->Flash->success(__('The inspection has been saved.'));
            }else{
                // echo "hel";
                pr($inspimg->errors());
                $this->Flash->error(__('The inspection could not be saved. Please, try again.'));
            
            }

        }

       $status = ['Scheduled' => 'Scheduled', 'Inspected' => 'Inspected'];
        $this->set('entryi',$entry_i);
        $this->set('status', $status);
        $this->set('title', 'Entry Inspection');
    }


    public function entryIndex() {
            $this->loadModel('Inspections');
        $this->loadModel('Properties');
        $this->loadModel('Users');
        $entryins = $this->Inspections->find('all',[
                    'conditions' => ['ins_type' => 'entry']
                ])->toArray();
       
        foreach ($entryins as $key => $value) {
            $propname = $this->Properties->find('all',[
                    'conditions' => ['id' => $value->property_id]
                ])->toArray();
            $staff = $this->Users->find('all',[
                    'conditions' => ['id' => $value->staff_id]
                ])->toArray();
            $entryins[$key] = $value->toArray();
            $prop_name = $propname[0]->refrence;
            $staff_name = $staff[0]->username;
            array_push($entryins[$key] ,$prop_name);
            array_push($entryins[$key], $staff_name);
        }
       // pr($entryins);//die;
         $this->set(compact(['entryins']));
        $this->set('title', 'Entry Inspections');
        //pr($openins);
    }
    public function routineIndex() {
        $this->loadModel('Inspections');
        $this->loadModel('Properties');
        $this->loadModel('Users');
        $routineins = $this->Inspections->find('all',[
                    'conditions' => ['ins_type' => 'routine']
        ])->toArray();
       
        foreach ($routineins as $key => $value) {
            $propname = $this->Properties->find('all',[
                    'conditions' => ['id' => $value->property_id]
                ])->toArray();
            $staff = $this->Users->find('all',[
                    'conditions' => ['id' => $value->staff_id]
                ])->toArray();
            $routineins[$key] = $value->toArray();
            $prop_name = $propname[0]->refrence;
            $staff_name = $staff[0]->username;
            array_push($routineins[$key] ,$prop_name);
            array_push($routineins[$key], $staff_name);
        }
       // pr($entryins);//die;
         $this->set(compact(['routineins']));
        $this->set('title', 'Routine Inspections');
        //pr($openins);
    }
    public function routineInspections($id = null) {
        $this->set('title', 'Routine Inspections');
    }
    
    public function exitInspections($id = null) {
        $this->loadModel('Properties');
        $this->loadModel('Users');
        $this->loadModel('Inspections');
        $this->loadModel('ExitInspections');
        $this->loadModel('ExitImages');
        $exit = "";
        $this->set('exit',$exit);
        $exit_i = $this->Inspections->find('all',[
                'conditions' => ['id'=> $id]
            ])->toArray();
        //pr($entry_i);die;
        foreach ($exit_i as $key => $value) {
            $prop = $this->Properties->find('all',[
                    'conditions' => ['id' => $value->property_id]
                ])->toArray();
            $staff = $this->Users->find('all',[
                    'conditions' => ['id'=>$value->staff_id]
                ])->toArray();
            $exit_i[$key]= $value->toArray();
            $prop_name = $prop[0]->refrence;
            $staff_name = $staff[0]->username;
            //echo $key;
            array_push($exit_i[$key] ,$prop_name);
            array_push($exit_i[$key] ,$staff_name);
        }

            $inspimg = $this->ExitInspections->newEntity();
            $inimg = $this->ExitImages->newEntity();
            if($this->request->is('post')){
                $pro_imgs_all = $this->request->getData();
                    foreach($pro_imgs_all['img'] as $proimg){
                        //pr($proimg);
                        //die;
                        $target_dir = "img/inspections/";
                        $target_file = $target_dir . basename($proimg['fimg']['name']);
                        $filename = $proimg['fimg']['name'];
                        $tempName = $proimg['fimg']['tmp_name'];
                        move_uploaded_file($tempName, $target_file);
                        $inimg = $this->ExitImages->patchEntity($inimg,$this->request->getData());
                        $inimg->entry_id = $id;
                        $inimg->imagename = $filename;
                        if($this->ExitImages->save($inimg)){
                            //pr($inimg->errors());
                        }else{
                           pr($inimg->errors()); 
                        }
                    }
            $inspimg = $this->ExitInspections->patchEntity($inspimg, $this->request->getData());            
            $inspimg->ins_id = $id;
            if($this->ExitInspections->save($inspimg)){
                //echo "hellll";
                $this->Flash->success(__('The inspection has been saved.'));
            }else{
                 //echo "hel";
                pr($inspimg->errors());
                $this->Flash->error(__('The inspection could not be saved. Please, try again.'));
            
            }

        }

       $status = ['Scheduled' => 'Scheduled', 'Inspected' => 'Inspected'];
        $this->set('exiti',$exit_i);
        $this->set('status', $status);
        $this->set('title', 'Exit Inspection');
    }

    public function exitIndex() {
            $this->loadModel('Inspections');
        $this->loadModel('Properties');
        $this->loadModel('Users');
        $exitins = $this->Inspections->find('all',[
                    'conditions' => ['ins_type' => 'exit']
                ])->toArray();
       
        foreach ($exitins as $key => $value) {
            $propname = $this->Properties->find('all',[
                    'conditions' => ['id' => $value->property_id]
                ])->toArray();
            $staff = $this->Users->find('all',[
                    'conditions' => ['id' => $value->staff_id]
                ])->toArray();
            $exitins[$key] = $value->toArray();
            $prop_name = $propname[0]->refrence;
            $staff_name = $staff[0]->username;
            array_push($exitins[$key] ,$prop_name);
            array_push($exitins[$key], $staff_name);
        }
       // pr($entryins);//die;
         $this->set(compact(['exitins']));
        $this->set('title', 'Exit Inspections');
        //pr($openins);
    }
    /**
     * Edit method
     *
     * @param string|null $id Inspection id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null) {
        $inspection = $this->Inspections->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $inspection = $this->Inspections->patchEntity($inspection, $this->request->getData());
            if ($this->Inspections->save($inspection)) {
                $this->Flash->success(__('The inspection has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The inspection could not be saved. Please, try again.'));
        }
        // $properties = $this->Inspections->Properties->find('list', ['limit' => 200]);
        $staff = $this->Inspections->Users->find('list', [
            'conditions' => ['group_id' => '11'],
            'keyField' => 'id',
            'valueField' => 'username'
        ]);
        $status = ['Active' => 'Active', 'Scheduled' => 'Scheduled', 'Inspected' => 'Inspected', 'Unscheduled' => 'Unscheduled', 'Closed' => 'Closed'];
        $this->set(compact('inspection', 'staff', 'status'));
        $this->set('title', 'Edit Inspection');
    }

    /**
     * Delete method
     *
     * @param string|null $id Inspection id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null) {
        $this->request->allowMethod(['post', 'delete']);
        $inspection = $this->Inspections->get($id);
        if ($this->Inspections->delete($inspection)) {
            $this->Flash->success(__('The inspection has been deleted.'));
        } else {
            $this->Flash->error(__('The inspection could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function staffMyInspections() {
        $uid = $this->Auth->User('id');
        $this->loadModel('Inspections');
        $my_inspections = $this->Inspections->find('all', [
            'conditions' => ['staff_id' => $uid]
        ]);
        $this->set(compact('my_inspections'));
        $this->set('title', 'My Inspections - Staff');
    }

    public function staffInspectionEdit($id = null) {
        $inspection = $this->Inspections->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $inspection = $this->Inspections->patchEntity($inspection, $this->request->getData());
            $status = $inspection->status;
            if ($this->Inspections->updateAll(['status' => $status], ['id' => $id])) {
                $this->Flash->success(__('The inspection status has been updated.'));

                return $this->redirect(['action' => 'staffMyInspections']);
            }
            $this->Flash->error(__('The inspection could not be updated. Please, try again.'));
        }
        
        $status = ['Active' => 'Active', 'Scheduled' => 'Scheduled', 'Inspected' => 'Inspected', 'Unscheduled' => 'Unscheduled', 'Closed' => 'Closed'];
        $this->set(compact('inspection', 'status'));
        $this->set('title', 'Edit Inspection - Staff');
    }

    public function managerMyInspections() {
        $uid = $this->Auth->User('id');
        $this->loadModel('Inspections');
        $my_inspections = $this->Inspections->find('all', [
            'conditions' => ['created_by' => $uid]
        ]);
        $this->set(compact('my_inspections'));
        $this->set('title', 'My Inspections - Manager');
    }

    public function inspectionTemplate($id = null){
    	$this->loadModel('Inspections');
    	$this->loadModel('Properties');
    	$this->loadModel('Users');
    	$this->loadModel('InspectionTemplates');
    	$entry = "";
        $this->set('entry',$entry);
        $entry_i = $this->Inspections->find('all',[
                'conditions' => ['id'=> $id]
            ])->toArray();
        //pr($entry_i);die;
        foreach ($entry_i as $key => $value) {
            $prop = $this->Properties->find('all',[
                    'conditions' => ['id' => $value->property_id]
                ])->toArray();
            $staff = $this->Users->find('all',[
                    'conditions' => ['id'=>$value->staff_id]
                ])->toArray();
            $entry_i[$key]= $value->toArray();
            $prop_name = $prop[0]->refrence;
            $staff_name = $staff[0]->username;
            //echo $key;
            array_push($entry_i[$key] ,$prop_name);
            array_push($entry_i[$key] ,$staff_name);
        }
        if($this->request->is('post')){

        	$inspecdata = $this->request->getData();
        	$i=0;
        	$field=array();
        	foreach ($inspecdata as $key => $value) {
        		if($key == 'fields_name'.$i)
        		{
        			$field[$i] = $value;
        			$i++;
        		}
        		else{
        			for($j=1 ; $j<=$value;$j++) {
        				$inspaection = $this->InspectionTemplates->newEntity();
        				$inspaection = $this->InspectionTemplates->patchEntity($inspaection, $this->request->getData());
        				$inspaection->ins_id = $id;
        				$inspaection->rooms = $field[$i-1]."".$j;
        				if($this->InspectionTemplates->save($inspaection)){
        					
        				}
        			}

        		}
            }
        	return $this->redirect(['action' => 'inspectionSubfields',$id]);
        	//pr($fieldata);

        }


       $status = ['Scheduled' => 'Scheduled', 'Inspected' => 'Inspected'];
        $this->set('entryi',$entry_i);
        $this->set('status', $status);
        $this->set('title', 'Update Entry Inspection');
    }

    public function inspectionSubfields($id = null) {
    	$this->set('title', 'Inspection Sub Fields');
    	$entry = "";
    	$this->set('entry',$entry);
    	$this->loadModel('InspectionTemplates');
    	$this->loadModel('InspectionSubfields');
    	$instemp = $this->InspectionTemplates->find('all',[
    		'conditions' => ['ins_id' => $id]
    		])->toArray();
    	$subfield = $this->request->getData();
    	$i = 1;
    	$j = 1;

    	$subvalue = array();
    	$subid = array();
    	$keyy = "";
    	$array1 = array();
    	$array2 = array();

    	foreach($subfield as $key => $value){
    		if($key == 'tempid'.$i."1") {
        			$tempid = $value;
        			$i++;
    		}    else   {
    			$array1[$key]=$value;
    			$array2[$key]=$tempid;
    		}
        }
    	foreach ($array1 as $key => $value) {
    		$subfil = $this->InspectionSubfields->newEntity();
    		$subfil = $this->InspectionSubfields->patchEntity($subfil, $this->request->getData());
    		$subfil->tempid = $array2[$key];
    		$subfil->subfieldname = $value;
    		if($this->InspectionSubfields->save($subfil)){
    			return $this->redirect(['action' => 'inspectionValues',$id]);
    		}
    	}
    	 $this->set('instemp',$instemp);
    }

    public function inspectionValues($id = null) {
		$entry = "";
		$this->set('entry',$entry);
        $this->set('title','Inspections Value');
		$this->loadModel('InspectionSubfields');
        $this->loadModel('InspectionTemplates');
		$this->loadModel('InspectionValues');
		$infield = $this->InspectionSubfields->find('all')->toArray();
		foreach ($infield as $key=>$fields) {
			$fieldname = $this->InspectionTemplates->find('all',[
				'conditions' => ['id' => $fields->tempid]
				])->toArray();
			$name = $fieldname[0]->rooms;
			$infield[$key] = $fields->toArray();
			array_push($infield[$key], $name);
		}
		if ($this->request->is('post')) {
			pr($this->request->data());
			$valuefil = $this->request->getData();
			$i=1;
			$tempid=array();
			$clean=array();
			$working=array();
			$undamage=array();
			$comment=array();
			foreach ($valuefil as $key=>$val) {
				if($key=='tempid'.$i)
				{
					$tempid[$i]=$val;
				}
				if($key=='clean'.$i)
				{
					$clean[$i]=$val;
				}
				if($key=='undamage'.$i)
				{
					$undamage[$i]=$val;
				}
				if($key=='working'.$i)
				{
					$working[$i]=$val;
				}
				if($key=='comment'.$i)
				{
					$comment[$i]=$val;
					$i++;
				}
			}
			for ($j=1;$j<=count($tempid);$j++) {
                $fieldval = $this->InspectionValues->newEntity();
                $fieldval = $this->InspectionValues->patchEntity($fieldval,$this->request->getData());
                $fieldval->templateid = $tempid[$j];
                $fieldval->clean = $clean[$j];
                $fieldval->working = $working[$j];
                $fieldval->undamaged = $undamage[$j];
                $fieldval->comment = $comment[$j];
                die;
                if($this->InspectionValues->save($fieldval)){
                    //echo $tempid[$j]."->".$clean[$j]."->".$undamage[$j]."->".$working[$j]."->".$comment[$j]."<br>";
                }
				//echo $tempid[$j]."->".$clean[$j]."->".$undamage[$j]."->".$working[$j]."->".$comment[$j]."<br>";
			}
		}
		$this->set('infield', $infield);
    }
}
