<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Network\Session\DatabaseSession;
/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class UsersController extends AppController
{
    public function initialize() {
       parent::initialize();
       $this->Auth->allow('login', 'logout', 'checkuser');
    }
    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        $this->viewBuilder()->setLayout('adminlayout');
        // $user = $this->Auth->user();
    }
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index() {
        // $this->paginate = [
        //     'contain' => ['Groups']
        // ];
        // $users = $this->paginate($this->Users);

        // $this->set(compact('users'));
        $this->loadModel('Users');
        $query = $this->Users->find('all');
        $users = $query->toArray();
        $this->set('users', $users);
        $this->set('title', 'All Users');
        $session = $this->request->session();
        $uid = $this->Auth->User('group_id');
		$session->write('user_id', $uid); 
		
       
        //pr($uid);
    }

    /**
     * View method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null) {
        $user = $this->Users->get($id, [
            'contain' => ['Properties','PropertyEnquiries', 'TenantDetails']
        ]);
        // $user = $this->Users->get($id, [
        //     'contain' => ['Groups', 'Aros', 'Properties', 'PropertyEnquiries']
        // ]);

        $this->set('user', $user);
        $this->set('title', 'User Details');
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add() {
        $uid = $this->Auth->User('id');
        $user = $this->Users->newEntity();
        if ($this->request->is('post')) {

            $user = $this->Users->patchEntity($user, $this->request->getData());
            $user->group_id = $user->role;
            $user->created_by = $uid;
            // pr($user->group_id);die;
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));

                return $this->redirect(['action' => 'index']);
            }   else   {
                $this->Flash->error(__('The user could not be saved. Please, try again.'));
            }
        }
        $groups = $this->Users->Groups->find('list', ['limit' => 200]);
        $this->set(compact('user', 'groups'));
        $this->set('title', 'Add User');
    }


    public function addTenant(){
    	$uid = $this->Auth->User('id');
        $user = $this->Users->newEntity();
        if ($this->request->is('post')) {

            $user = $this->Users->patchEntity($user, $this->request->getData());
            $user->group_id = 12;
            $user->created_by = $uid;
            // pr($user->group_id);die;
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The Tenant has been saved.'));

                return $this->redirect(['action' => 'index']);
            }   else   {
                $this->Flash->error(__('The Tenant could not be saved. Please, try again.'));
            }
        }
        // $groups = $this->Users->Groups->find('list', ['limit' => 200]);
        $this->set(compact('user'));
        $this->set('title', 'Add Tenant');
    }
    public function addAgent()
    {

        $uid = $this->Auth->User('id');
        $user = $this->Users->newEntity();
        if ($this->request->is('post')) {

            $user = $this->Users->patchEntity($user, $this->request->getData());
            $user->group_id = 21;
            $user->created_by = $uid;
            // pr($user->group_id);die;
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The Agent has been saved.'));

                return $this->redirect(['action' => 'index']);
            }   else   {
                $this->Flash->error(__('The Agent could not be saved. Please, try again.'));
            }
        }
        // $groups = $this->Users->Groups->find('list', ['limit' => 200]);
        $this->set(compact('user'));
        $this->set('title', 'Add Agent');

    }
    /**
     * Edit method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null) {
        $user = $this->Users->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The user could not be saved. Please, try again.'));
        }
        $groups = $this->Users->Groups->find('list', ['limit' => 200]);
        $this->set(compact('user', 'groups'));
        $this->set('title', 'Edit User');
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null) {
        $this->request->allowMethod(['post', 'delete']);
        $user = $this->Users->get($id);
        if ($this->Users->delete($user)) {
            $this->Flash->success(__('The user has been deleted.'));
        } else {
            $this->Flash->error(__('The user could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
    public function login() {
        if(!is_null($this->request->session()->read('Auth.User.id'))) {
            $this->redirect(['controller' => 'Homes', 'action' => 'index']);
        }   else   {
            if ($this->request->is('post')) {
            $user = $this->Auth->identify();
            if ($user) {
                $this->Auth->setUser($user);
                // $this->checkuser($user['group_id']);
                return $this->redirect($this->Auth->redirectUrl());
            }   else   {
            $this->Flash->error(__('Your username or password was incorrect.'));
            }
        }
        }
        $this->viewBuilder()->setLayout('login');
        $this->set('title', 'LogIn - Mccarthysrealestate');
    }

    public function logout() {
        //Leave empty for now.
        $this->Flash->success(__('Good-Bye'));
        $this->redirect($this->Auth->logout());
    }
   public function changepassword() {
        $user =$this->Users->get($this->Auth->user('id'));
        if (!empty($this->request->data)) {
            $user = $this->Users->patchEntity($user, [
                    'old_password'  => $this->request->data['old_password'],
                    'password'      => $this->request->data['password1'],
                    'password1'     => $this->request->data['password1'],
                    'password2'     => $this->request->data['password2']
                ],
                ['validate' => 'password']
            );
            if ($this->Users->save($user)) {
                $this->Flash->success('The password is successfully changed');
                // $this->redirect('/index');
            } else {
                $this->Flash->error('There was an error during the save!');
            }
        }
        $this->set('user',$user);
        $this->set('title', 'Change Password');
    }

    public function profile() {
        $us_id = $this->Users->get($this->Auth->user('id'), [
        'contain' => ['TenantDetails']
        ]);
        $this->set('userprofile', $us_id);
        $this->set('title', 'My Profile');
    }
    public function adminallproperties() {
        $this->loadModel('Properties');       

        $query = $this->Properties->find('all', array(
            'contain' => array('PropertyImages')
            ))->limit(30);
       
        $property = $query->toArray();
        
        $this->set('properties', $property);
    }

    public function contacts() {
        
    }
    public function inbox() {
        
    }
    public function tasks() {
        
    }
    
    public function jobs() {
        
    }
    public function addStaff() {
        $uid = $this->Auth->User('id');
        $user = $this->Users->newEntity();
        if ($this->request->is('post')) {

            $user = $this->Users->patchEntity($user, $this->request->getData());
            $user->group_id = 11;
            $user->created_by = $uid;
            // pr($user->group_id);die;
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The staff has been saved.'));

                // return $this->redirect(['action' => 'index']);
            }   else   {
                $this->Flash->error(__('The staff could not be saved. Please, try again.'));
            }
        }
        // $groups = $this->Users->Groups->find('list', ['limit' => 200]);
        $this->set(compact('user'));
        $this->set('title', 'Add Staff');
    }

    public function managerMyStaff() {
        $uid = $this->Auth->User('id');
        $this->loadModel('Users');
        $staff = $this->Users->find('all', [
            'conditions' => ['created_by' => $uid]
        ]);
        $this->set(compact('staff'));
        $this->set('title', 'My Staff - Manager');
    }
    public function dashboard() {
        $this->set('title', 'Dashboard');
    }
    public function addOwner() {
        $uid = $this->Auth->User('id');
        $user = $this->Users->newEntity();
        if ($this->request->is('post')) {

            $user = $this->Users->patchEntity($user, $this->request->getData());
            $user->group_id = 10;
            $user->created_by = $uid;
            // pr($user->group_id);die;
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The Owner has been saved.'));

                // return $this->redirect(['action' => 'index']);
            }   else   {
                $this->Flash->error(__('The Owner could not be saved. Please, try again.'));
            }
        }
        // $groups = $this->Users->Groups->find('list', ['limit' => 200]);
        $this->set(compact('user'));
        $this->set('title', 'Add Owner');
    }
    public function listOwners() {
        $owners = $this->Users->find('all', [
        'conditions' => ['group_id' => 10]
        ]);
        $this->set(compact('owners'));
        $this->set('title', 'List Owners');
    }
    // public function checkuser($usera = NULL) {
    //     // pr($usera);die;
    //     // $this->loadModel('UserProfiles');
    //     if($usera == 9){
    //         $this->redirect(['controller' => 'Users', 'action' => 'index']);
    //     }elseif($usera == 10)   {
    //         $this->redirect(['controller' => 'Properties', 'action' => 'managerMyProperties']);
    //     }elseif($usera == 11)   {
    //         $this->redirect(['controller' => 'Inspections', 'action' => 'staffMyInspections']);
    //     }elseif($usera == 12)   {
    //         $this->redirect(['controller' => 'Homes', 'action' => 'index']);
    //     }elseif($usera == 16)   {
    //         $this->redirect(['controller' => 'Properties', 'action' => 'myproperties']);
    //     }
    // }
}
