<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
/**
 * TenantDetails Controller
 *
 * @property \App\Model\Table\TenantDetailsTable $TenantDetails
 *
 * @method \App\Model\Entity\TenantDetail[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class TenantDetailsController extends AppController
{
    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        $this->viewBuilder()->setLayout('homepage');
        $this->set('title', 'Add Tenant Details');
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Users', 'Properties']
        ];
        $tenantDetails = $this->paginate($this->TenantDetails);

        $this->set(compact('tenantDetails'));
        $this->viewBuilder()->setLayout('adminlayout');
        $this->set('title', 'All Tenant Details');
    }

    /**
     * View method
     *
     * @param string|null $id Tenant Detail id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $tenantDetail = $this->TenantDetails->get($id, [
            'contain' => ['Users', 'Properties']
        ]);

        $this->set('tenantDetail', $tenantDetail);
        $this->viewBuilder()->setLayout('adminlayout');
        $this->set('title', 'View Tenant Details');
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add($tan_id = null, $prop_id = null)
    {
        $tenantDetail = $this->TenantDetails->newEntity();
        if ($this->request->is('post')) {
            $tenantDetail = $this->TenantDetails->patchEntity($tenantDetail, $this->request->getData());
            $tenantDetail->tenant_id = $tan_id;
            $tenantDetail->property_id = $prop_id;
            $res = $this->TenantDetails->find('list', [
                'conditions' => ['tenant_id' => $tan_id]
            ])->toArray();
            // pr($res);die;
            if(sizeof($res) > 0) {
                $tenantDetail = [];
                return $this->Flash->error(__('The Tanent Information is already added.'));
            }   else   {
                if ($this->TenantDetails->save($tenantDetail)) {
                    $this->Flash->success(__('The tenant detail has been saved.'));

                    // return $this->redirect(['action' => 'index']);
                }   else   {
                    $this->Flash->error(__('The tenant detail could not be saved. Please, try again.'));
                }
            }
                
            
        }
        // $tenants = $this->TenantDetails->Users->find('list', ['limit' => 200]);
        // $properties = $this->TenantDetails->Properties->find('list', ['limit' => 200]);

        $this->set(compact('tenantDetail'));
        $this->set('title', 'Add Tenant Details');
    }

    /**
     * Edit method
     *
     * @param string|null $id Tenant Detail id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $tenantDetail = $this->TenantDetails->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $tenantDetail = $this->TenantDetails->patchEntity($tenantDetail, $this->request->getData());
            if ($this->TenantDetails->save($tenantDetail)) {
                $this->Flash->success(__('The tenant detail has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The tenant detail could not be saved. Please, try again.'));
        }
        // $tenants = $this->TenantDetails->Tenants->find('list', ['limit' => 200]);
        // $properties = $this->TenantDetails->Properties->find('list', ['limit' => 200]);
        $this->set(compact('tenantDetail'));
        $this->set('title', 'Edit Tanent Detail');
        $this->viewBuilder()->setLayout('adminlayout');
    }

    /**
     * Delete method
     *
     * @param string|null $id Tenant Detail id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $tenantDetail = $this->TenantDetails->get($id);
        if ($this->TenantDetails->delete($tenantDetail)) {
            $this->Flash->success(__('The tenant detail has been deleted.'));
        } else {
            $this->Flash->error(__('The tenant detail could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
