<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * OpenInspection Entity
 *
 * @property int $id
 * @property int $property_id
 * @property string $name
 * @property string $phone
 * @property string $email
 * @property int $no_person
 * @property \Cake\I18n\FrozenDate $date
 * @property \Cake\I18n\FrozenTime $from_time
 * @property \Cake\I18n\FrozenTime $to_time
 * @property string $status
 * @property string $notes
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 *
 * @property \App\Model\Entity\Property $property
 */
class OpenInspection extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'property_id' => true,
        'name' => true,
        'phone' => true,
        'email' => true,
        'no_person' => true,
        'date' => true,
        'from_time' => true,
        'to_time' => true,
        'status' => true,
        'notes' => true,
        'created' => true,
        'modified' => true,
        'property' => true
    ];
}
