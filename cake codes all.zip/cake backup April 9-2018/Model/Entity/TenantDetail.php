<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * TenantDetail Entity
 *
 * @property int $id
 * @property string $first_name
 * @property string $last_name
 * @property string $contact_no
 * @property \Cake\I18n\FrozenDate $rent_from
 * @property \Cake\I18n\FrozenDate $rent_to
 * @property int $tenant_id
 * @property int $property_id
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 *
 * @property \App\Model\Entity\Tenant $tenant
 * @property \App\Model\Entity\Property $property
 */
class TenantDetail extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'first_name' => true,
        'last_name' => true,
        'contact_no' => true,
        'rent_from' => true,
        'rent_to' => true,
        'tenant_id' => true,
        'property_id' => true,
        'created' => true,
        'modified' => true,
        'tenant' => true,
        'property' => true
    ];
}
