<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Property Entity
 *
 * @property int $id
 * @property string $refrence
 * @property int $manager_id
 * @property string $address
 * @property string $type_of_property
 * @property int $no_of_bedrooms
 * @property int $no_of_bathrooms
 * @property int $no_of_car_spaces
 * @property string $description
 * @property int $key_number
 */
class Property extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    public function parentNode() {
        return null;
    }
    protected $_accessible = [
        'refrence' => true,
        'address' => true,
        'state' => true,
        'city' => true,
        'post_code' => true,
        'type_of_property' => true,
        'no_of_bedrooms' => true,
        'no_of_bathrooms' => true,
        'no_of_car_spaces' => true,
        'description' => true,
        'user_id' => true,
        'status' => true,
        'created' => true,
        'modified' => true
    ];
}
