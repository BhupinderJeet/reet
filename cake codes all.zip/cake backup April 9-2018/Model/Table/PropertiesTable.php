<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Properties Model
 *
 * @property |\Cake\ORM\Association\BelongsTo $Managers
 *
 * @method \App\Model\Entity\Property get($primaryKey, $options = [])
 * @method \App\Model\Entity\Property newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Property[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Property|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Property patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Property[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Property findOrCreate($search, callable $callback = null, $options = [])
 */
class PropertiesTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);
        $this->addBehavior('Acl.Acl', ['controlled']);
        $this->setTable('properties');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');
        $this->addBehavior('Timestamp');
        
        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);
        
        $this->hasMany('PropertyImages', [
        'foreignKey' => 'property_id'
        ]);

        $this->hasMany('PropertyEnquiries', [
        'foreignKey' => 'property_id'
        ]);  

        $this->hasMany('PropertyAssigns', [
        'foreignKey' => 'property_id'
        ]);

        $this->hasMany('Inspections', [
        'foreignKey' => 'property_id'
        ]);

        $this->hasMany('InvoiceDetails', [
        'foreignKey' => 'property_id'
        ]);

    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('refrence')
            ->maxLength('refrence', 20)
            ->requirePresence('refrence', 'create')
            ->notEmpty('refrence');

        $validator
            ->scalar('address')
            ->maxLength('address', 300)
            ->requirePresence('address', 'create')
            ->notEmpty('address');

        $validator
            ->scalar('state')
            ->maxLength('state', 300)
            ->requirePresence('state', 'create')
            ->notEmpty('state');

        $validator
            ->scalar('city')
            ->maxLength('city', 300)
            ->requirePresence('city', 'create')
            ->notEmpty('city');

        $validator
            ->scalar('post_code')
            ->maxLength('post_code', 4)
            ->requirePresence('post_code', 'create')
            ->notEmpty('post_code');

        $validator
            ->scalar('type_of_property')
            ->requirePresence('type_of_property', 'create')
            ->notEmpty('type_of_property');

        $validator
            ->integer('no_of_bedrooms')
            ->requirePresence('no_of_bedrooms', 'create')
            ->notEmpty('no_of_bedrooms');

        $validator
            ->integer('no_of_bathrooms')
            ->requirePresence('no_of_bathrooms', 'create')
            ->notEmpty('no_of_bathrooms');

        $validator
            ->integer('no_of_car_spaces')
            ->requirePresence('no_of_car_spaces', 'create')
            ->notEmpty('no_of_car_spaces');

        $validator
            ->scalar('description')
            ->maxLength('description', 300)
            ->requirePresence('description', 'create')
            ->notEmpty('description');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        //$rules->add($rules->existsIn(['manager_id'], 'Managers'));

        return $rules;
    }
}
