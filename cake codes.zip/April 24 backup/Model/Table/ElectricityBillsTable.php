<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * ElectricityBills Model
 *
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\BelongsTo $Users
 * @property \App\Model\Table\PropertiesTable|\Cake\ORM\Association\BelongsTo $Properties
 *
 * @method \App\Model\Entity\ElectricityBill get($primaryKey, $options = [])
 * @method \App\Model\Entity\ElectricityBill newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\ElectricityBill[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\ElectricityBill|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\ElectricityBill patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\ElectricityBill[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\ElectricityBill findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class ElectricityBillsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('electricity_bills');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'tenant_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Properties', [
            'foreignKey' => 'property_id',
            'joinType' => 'INNER'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->integer('meter_number')
            ->requirePresence('meter_number', 'create')
            ->notEmpty('meter_number');

        $validator
            ->integer('units_consumed')
            ->requirePresence('units_consumed', 'create')
            ->notEmpty('units_consumed');

        $validator
            ->integer('bill_amount')
            ->requirePresence('bill_amount', 'create')
            ->notEmpty('bill_amount');

        $validator
            ->integer('other_charges')
            ->requirePresence('other_charges', 'create')
            ->notEmpty('other_charges');

        $validator
            ->date('due_date')
            ->requirePresence('due_date', 'create')
            ->notEmpty('due_date');

        $validator
            ->integer('amount_after_due_date')
            ->requirePresence('amount_after_due_date', 'create')
            ->notEmpty('amount_after_due_date');

        $validator
            ->integer('status')
            ->requirePresence('status', 'create')
            ->notEmpty('status');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['tenant_id'], 'Users'));
        $rules->add($rules->existsIn(['property_id'], 'Properties'));

        return $rules;
    }
}
