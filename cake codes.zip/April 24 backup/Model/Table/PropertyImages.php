<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class PropertyImages extends Table {
	public function initialize(array $config) {
		parent::initialize($config);

		$this->setTable('property_images');
		$this->setDisplayField('id');
		$this->setPrimaryKey('id');

		$this->belongsTo('properties', [
				'foreignKey' => 'property_id',
				'joinType' => 'INNER'
			]);
	}

	public function validationDefault(Validator $validator) {
		$validator
			->integer('id');
			->allowEmpty('id', 'create');

		$validator
            ->scalar('img_url')
            ->maxLength('img_url', 120)
            ->requirePresence('img_url', 'create')
            ->notEmpty('img_url');

        $validator
            ->integer('property_id')
            ->requirePresence('property_id', 'create')
            ->notEmpty('property_id');
	}
}



?>