<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ExitInspection Entity
 *
 * @property int $id
 * @property int $ins_id
 * @property string $clean
 * @property string $undamaged
 * @property string $working
 * @property string $comments
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 *
 * @property \App\Model\Entity\In $in
 */
class ExitInspection extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'ins_id' => true,
        'clean' => true,
        'undamaged' => true,
        'working' => true,
        'comments' => true,
        'created' => true,
        'modified' => true,
    ];
}
