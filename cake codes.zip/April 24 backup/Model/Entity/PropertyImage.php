<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;



class PropertyImage extends Entity {

	protected $_accessible = [
		'img_url' => true,
		'property_id' => true
	];
}

?>