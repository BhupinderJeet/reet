<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * ElectricityBill Entity
 *
 * @property int $id
 * @property int $tenant_id
 * @property int $property_id
 * @property int $meter_number
 * @property int $units_consumed
 * @property int $bill_amount
 * @property int $other_charges
 * @property \Cake\I18n\FrozenDate $due_date
 * @property int $amount_after_due_date
 * @property int $status
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 *
 * @property \App\Model\Entity\User $user
 * @property \App\Model\Entity\Property $property
 */
class ElectricityBill extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'tenant_id' => true,
        'property_id' => true,
        'meter_number' => true,
        'units_consumed' => true,
        'bill_amount' => true,
        'other_charges' => true,
        'due_date' => true,
        'amount_after_due_date' => true,
        'status' => true,
        'created' => true,
        'modified' => true,
        'user' => true,
        'property' => true
    ];
}
