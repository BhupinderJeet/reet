<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * WaterBill Entity
 *
 * @property int $id
 * @property int $start_reading
 * @property int $end_reading
 * @property \Cake\I18n\FrozenDate $from_date
 * @property \Cake\I18n\FrozenDate $to_date
 * @property int $meter_no
 * @property int $bill_amount
 * @property \Cake\I18n\FrozenDate $due_date
 * @property int $bill_after_due_date
 * @property int $property_id
 * @property int $tenant_id
 * @property int $status
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 *
 * @property \App\Model\Entity\Property $property
 * @property \App\Model\Entity\User $user
 */
class WaterBill extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'start_reading' => true,
        'end_reading' => true,
        'from_date' => true,
        'to_date' => true,
        'meter_no' => true,
        'bill_amount' => true,
        'due_date' => true,
        'bill_after_due_date' => true,
        'property_id' => true,
        'tenant_id' => true,
        'status' => true,
        'created' => true,
        'modified' => true,
        'property' => true,
        'user' => true
    ];
}
