<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * InvoiceDetail Entity
 *
 * @property int $id
 * @property int $tenant_id
 * @property int $property_id
 * @property \Cake\I18n\FrozenDate $due_date
 * @property \Cake\I18n\FrozenDate $created_date
 * @property int $total_amount
 * @property int $status
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 *
 * @property \App\Model\Entity\User $user
 * @property \App\Model\Entity\Property $property
 */
class InvoiceDetail extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'id' => true,
        'tenant_id' => true,
        'property_id' => true,
        'due_date' => true,
        'created_date' => true,
        'total_amount' => true,
        'status' => true,
        'created' => true,
        'modified' => true
    ];
}
