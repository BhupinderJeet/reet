<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Controller\Controller;
use Cake\Event\Event;
use Cake\I18n\Time;

class HomesController extends AppController {
    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        $this->viewBuilder()->setLayout('homepage');

        $this->Auth->allow(['index', 'contact', 'allproperties']);
    }
	public function index(){
    	$this->loadModel('Posts');
        $posts = $this->Posts->find('all')->limit(3);
        // pr($posts->toArray());die;
        $this->set('posts', $posts->toArray());
        $this->set('title', 'Mccarthysrealestate');
    }

    public function contact() {
        $this->loadModel('Contacts'); 
    	$contact = $this->Contacts->newEntity();
        if ($this->request->is('post')) {
            $contact = $this->Contacts->patchEntity($contact, $this->request->getData());
            if ($this->Contacts->save($contact)) {
                $this->Flash->success(__('The Query has been sent.'));

                return $this->redirect(['action' => 'contact']);
            }else  {
                $this->Flash->error(__('The contact could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('contact'));
        $this->set('title', 'Contact Us');
    }

    public function loginagent() {
    	
    }
    public function loginclient() {
    	
    }
    public function aboutus() {
        
    }
    public function allproperties() {
        $this->loadModel('Properties');       

        $query = $this->Properties->find('all', array(
            'contain' => array('PropertyImages')
            ))->limit(30);
        
        $property = $query->toArray();
        
        //$property = $query->toArray();
        //debug($property);
        $this->set('properties', $property);
        $this->set('title', 'All Properties');
    }
    public function viewproperty($id = null) {
        $this->loadModel('Properties');       

        $query = $this->Properties->find('all', array(
            'contain' => array('PropertyImages'),
            'conditions' => ['id' => $id]
            ))->limit(10);
       
        $property = $query->toArray();

        $this->set('property', $property);
        $this->set('title', 'Details View');
    }
    public function contactowner($id = null) {
        $this->loadModel('PropertyEnquiries');
        $property_enquiry = $this->PropertyEnquiries->newEntity();
        if ($this->request->is('post')) {
            $property_enquiry = $this->PropertyEnquiries->patchEntity($property_enquiry, $this->request->getData());
            
            $uid = $this->Auth->User('id');

            //pr($uid); die();
            $property_enquiry->user_id = $uid;
            $property_enquiry->property_id = $id;
            
            if ($this->PropertyEnquiries->save($property_enquiry)) {
                $this->Flash->success(__('The property enquiry has been saved. The Owner will contact You Soon.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The property could not be saved. Please, try again.'));
        }

        
        $this->set(compact('property_enquiry'));
        $this->set('title', 'Contact Owner');
    }

    public function searchresult() {
        if($this->request->is('post')) {
            $glo = $this->request->data;
            unset($glo['sort_by']);
            unset($glo['submit']);
           $conditions = [];
            foreach($glo as $key=>$value){
                if(is_array($value)){
                    if(count($value) > 1){
                        foreach($value as $value1){
                            $conditions["OR"]["$key IN"][] = $value1;
                        }
                    }else{
                        $conditions["OR"]["$key IN"] = $value;
                    }
                }else{
                    $conditions["OR"][$key] = $value;
                }
            }
           // pr($conditions);
            $this->loadModel('Properties');       
            
            $query = $this->Paginator->paginate($this->Properties->find('all', array(
                'contain' => array('PropertyImages'),
                'conditions' => $conditions
                ))->limit(10));

             //pr($query);
            $filter = $query->toArray();
            //pr($filter);
            $this->set('filter', $filter);
        }
        $this->set('title', 'Search Result');
    }

    public function profile() {
        $this->loadModel('Users');
        $us_id = $this->Users->get($this->Auth->user('id'), [
        'contain' => ['TenantDetails']
        ]);
        // pr($us_id->toArray());die;
        $this->set('userprofile', $us_id);
        $this->loadModel('InvoiceDetails');
        $invoicedata = $this->InvoiceDetails->find('all',[
            'conditions' =>['id', $this->Auth->user('id')]
            ])->max('id')->toArray();
        $due_date = $invoicedata['due_date'];
        $now = Time::now();
        $diff  = date_diff( $due_date, $now );
        $this->set('datediff', $diff);
        $this->set('title', 'My Account');
    }
    public function changepassword() {
        $this->loadModel('Users');
        $user =$this->Users->get($this->Auth->user('id'));
        if (!empty($this->request->data)) {
            $user = $this->Users->patchEntity($user, [
                    'old_password'  => $this->request->data['old_password'],
                    'password'      => $this->request->data['password1'],
                    'password1'     => $this->request->data['password1'],
                    'password2'     => $this->request->data['password2']
                ],
                ['validate' => 'password']
            );
            if ($this->Users->save($user)) {
                $this->Flash->success('The password is successfully changed');
                // $this->redirect('/index');
            } else {
                $this->Flash->error('There was an error during the save!');
            }
        }
        $this->set('user',$user);
        $this->set('title', 'Change Password');
    }

    public function assignmentdetailsclient() {
        $uid = $this->Auth->User('id');
        $this->loadModel('PropertyAssigns');
        $query = $this->PropertyAssigns->find('all',[
            'conditions' => ['tenant_id' => $uid]
        ]);
        $assign = $query->toArray();
        $this->loadModel('Properties');
        if(sizeof($assign) > 0) {
            $property_details = $this->Properties->find('all', [
                'conditions' => ['id' => $assign[0]['property_id']],
                'contain' => ['PropertyImages']
            ]);
            $this->set('property_details', $property_details->toArray());
            $this->set('assign', $query->toArray());
        }   else   {
            $this->set('property_details', 0);
            $this->set('assign', 0);
        }
        $this->set('title', 'Your Assignment Details');
    }
    public function editProfile($id = null) {
        $this->loadModel('Users');
        $user = $this->Users->get($id);
        pr($user->toArray());die;
        $this->set('title', 'Edit Your Profile');
    }

    public function viewPost($id = null) {
        $this->loadModel('Posts');
        $post = $this->Posts->get($id);
        // pr($post->toArray());die;
        $this->set('post', $post->toArray());
        $this->set('title', 'Post Details');
    }
}
?>