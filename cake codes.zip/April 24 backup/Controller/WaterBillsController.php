<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
/**
 * WaterBills Controller
 *
 * @property \App\Model\Table\WaterBillsTable $WaterBills
 *
 * @method \App\Model\Entity\WaterBill[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class WaterBillsController extends AppController
{
    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        $this->viewBuilder()->setLayout('adminlayout');
    }

    public function initialize() {
        parent::initialize();
        $this->loadComponent('RequestHandler');
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Properties', 'Users']
        ];
        $waterBills = $this->paginate($this->WaterBills);

        $this->set(compact('waterBills'));
        $this->set('title', 'Water Bills');
    }

    /**
     * View method
     *
     * @param string|null $id Water Bill id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $waterBill = $this->WaterBills->get($id, [
            'contain' => ['Properties', 'Users']
        ]);

        $this->set('waterBill', $waterBill);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add($t_id = null, $p_id = null)
    {
        $waterBill = $this->WaterBills->newEntity();
        if ($this->request->is('post')) {
            $waterBill = $this->WaterBills->patchEntity($waterBill, $this->request->getData());
            $waterBill->tenant_id = $t_id;
            $waterBill->property_id = $p_id;
            $waterBill->status = 0;
            if ($this->WaterBills->save($waterBill)) {
                $this->Flash->success(__('The water bill has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The water bill could not be saved. Please, try again.'));
        }
        $this->set(compact('waterBill'));
        $this->set('title', 'Generate Water Bill');
    }

    /**
     * Edit method
     *
     * @param string|null $id Water Bill id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $waterBill = $this->WaterBills->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $waterBill = $this->WaterBills->patchEntity($waterBill, $this->request->getData());
            if ($this->WaterBills->save($waterBill)) {
                $this->Flash->success(__('The water bill has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The water bill could not be saved. Please, try again.'));
        }
        $properties = $this->WaterBills->Properties->find('list', ['limit' => 200]);
        $users = $this->WaterBills->Users->find('list', ['limit' => 200]);
        $this->set(compact('waterBill', 'properties', 'users'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Water Bill id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $waterBill = $this->WaterBills->get($id);
        if ($this->WaterBills->delete($waterBill)) {
            $this->Flash->success(__('The water bill has been deleted.'));
        } else {
            $this->Flash->error(__('The water bill could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function viewWaterBill($id = null) {
        $w_bill = $this->WaterBills->get($id);
        // pr($w_bill);die;
        $this->loadModel('Users');
        $this->loadModel('Properties');
        $tenant = $this->Users->get($w_bill->tenant_id)->username;
        $property_address = $this->Properties->get($w_bill->property_id)->address;
        $owner = $this->Users->get($this->Properties->get($w_bill->property_id)->user_id)->username;
        
        $this->set('tenant', $tenant);
        $this->set('property_address', $property_address);
        $this->set('owner', $owner);
        $this->set('water_bill', $w_bill);

        $this->viewBuilder()->setLayout('homepage');
        $this->set('title', 'Water Bill');
    }

    public function waterBillPdf($id = null) {
        $w_bill = $this->WaterBills->get($id);
        
        $this->loadModel('Users');
        $this->loadModel('Properties');
        $tenant = $this->Users->get($w_bill->tenant_id)->username;
        $property_address = $this->Properties->get($w_bill->property_id)->address;
        $owner = $this->Users->get($this->Properties->get($w_bill->property_id)->user_id)->username;
        
        $this->set('tenant', $tenant);
        $this->set('property_address', $property_address);
        $this->set('owner', $owner);
        $this->set('water_bill', $w_bill);

        $this->viewBuilder()->setLayout('');
        $this->viewBuilder()->options([
            'pdfConfig' => [
                'orientation' => 'portrait',
                'filename' => 'Invoice_' . $id
            ]
        ]);

        $this->RequestHandler->renderAs($this, 'pdf', ['attachment' => 'filename.pdf']);
    }

    
}
