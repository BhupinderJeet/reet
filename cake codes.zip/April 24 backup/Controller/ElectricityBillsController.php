<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
/**
 * ElectricityBills Controller
 *
 * @property \App\Model\Table\ElectricityBillsTable $ElectricityBills
 *
 * @method \App\Model\Entity\ElectricityBill[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ElectricityBillsController extends AppController
{
    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        $this->viewBuilder()->setLayout('adminlayout');
    }

    public function initialize() {
        parent::initialize();
        $this->loadComponent('RequestHandler');
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Users', 'Properties']
        ];
        $electricityBills = $this->paginate($this->ElectricityBills);

        $this->set(compact('electricityBills'));
        $this->set('title', 'Electricity Bills');
    }

    /**
     * View method
     *
     * @param string|null $id Electricity Bill id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $electricityBill = $this->ElectricityBills->get($id, [
            'contain' => ['Users', 'Properties']
        ]);

        $this->set('electricityBill', $electricityBill);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add($t_id = null, $p_id = null)
    {
        $electricityBill = $this->ElectricityBills->newEntity();
        if ($this->request->is('post')) {
            $electricityBill = $this->ElectricityBills->patchEntity($electricityBill, $this->request->getData());
            $electricityBill->tenant_id = $t_id;
            $electricityBill->property_id = $p_id;
            $electricityBill->status = 0;
            if ($this->ElectricityBills->save($electricityBill)) {
                $this->Flash->success(__('The electricity bill has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The electricity bill could not be saved. Please, try again.'));
        }
        $users = $this->ElectricityBills->Users->find('list', ['limit' => 200]);
        $properties = $this->ElectricityBills->Properties->find('list', ['limit' => 200]);
        $this->set(compact('electricityBill', 'users', 'properties'));
        $this->set('title', 'Generate Electricity Bill');
    }

    /**
     * Edit method
     *
     * @param string|null $id Electricity Bill id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $electricityBill = $this->ElectricityBills->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $electricityBill = $this->ElectricityBills->patchEntity($electricityBill, $this->request->getData());
            if ($this->ElectricityBills->save($electricityBill)) {
                $this->Flash->success(__('The electricity bill has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The electricity bill could not be saved. Please, try again.'));
        }
        $users = $this->ElectricityBills->Users->find('list', ['limit' => 200]);
        $properties = $this->ElectricityBills->Properties->find('list', ['limit' => 200]);
        $this->set(compact('electricityBill', 'users', 'properties'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Electricity Bill id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $electricityBill = $this->ElectricityBills->get($id);
        if ($this->ElectricityBills->delete($electricityBill)) {
            $this->Flash->success(__('The electricity bill has been deleted.'));
        } else {
            $this->Flash->error(__('The electricity bill could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function viewElectricityBill($id = null) {
        $this->viewBuilder()->setLayout('homepage');
        $e_bill = $this->ElectricityBills->get($id);
        // pr($e_bill);die;
        $this->loadModel('Properties');
        $this->loadModel('Users');
        $property_det = $this->Properties->get($e_bill->property_id);
        
        $p_address = $property_det->address;

        $owner = $this->Users->get($property_det->user_id)->username;
        
        $tenant = $this->Users->get($e_bill->tenant_id)->username;

        $this->set('electricityBill', $e_bill);
        $this->set('tenant_address', $p_address);
        $this->set('owner', $owner);
        $this->set('tenant', $tenant);
        $this->set('title', 'View Electricity Bill');
    }

    public function electricityBillPdf($id = null) {
        
        $e_bill = $this->ElectricityBills->get($id);
        // pr($e_bill);die;
        $this->loadModel('Properties');
        $this->loadModel('Users');
        $property_det = $this->Properties->get($e_bill->property_id);
        
        $p_address = $property_det->address;

        $owner = $this->Users->get($property_det->user_id)->username;
        
        $tenant = $this->Users->get($e_bill->tenant_id)->username;

        $this->set('electricityBill', $e_bill);
        $this->set('tenant_address', $p_address);
        $this->set('owner', $owner);
        $this->set('tenant', $tenant);
        
        $this->viewBuilder()->setLayout('');
        $this->viewBuilder()->options([
            'pdfConfig' => [
                'orientation' => 'portrait',
                'filename' => 'Invoice_' . $id
            ]
        ]);

        $this->RequestHandler->renderAs($this, 'pdf', ['attachment' => 'filename.pdf']);
    }
}
