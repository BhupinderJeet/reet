<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;

/**
 * Groups Controller
 *
 * @property \App\Model\Table\GroupsTable $Groups
 *
 * @method \App\Model\Entity\Group[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class GroupsController extends AppController
{
    public function initialize()
    {
        parent::initialize();
       // $this->Auth->allow();
        
    }
    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        $this->viewBuilder()->setLayout('adminlayout');
    }
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $groups = $this->paginate($this->Groups);

        $this->set(compact('groups'));
        $this->set('title', 'All Groups');
    }

    /**
     * View method
     *
     * @param string|null $id Group id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {   
        // $user = $this->Groups->get($id, [
        //     'contain' => ['Aros', 'Properties', 'PropertyEnquiries']
        // ]);
        $group = $this->Groups->get($id, [
            'contain' => ['Users']
        ]);

        $this->set('group', $group);
        $this->set('title', 'Group Details');
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        
        $group = $this->Groups->newEntity();
        if ($this->request->is('post')) {
            $group = $this->Groups->patchEntity($group, $this->request->getData());
            if ($this->Groups->save($group)) {
                $this->Flash->success(__('The group has been saved.'));

                return $this->redirect(['action' => 'index']);
            }   else   {
                $this->Flash->error(__('The group could not be saved. Please, try again.'));
            }
            
        }
        $this->set(compact('group'));
        $this->set('title', 'Add Group');
        // $job = new AclExtrasShell();
        // $job->startup();
        // $job->dispatchMethod('aco_sync');


        $shell = new \Cake\Console\Shell;
        $shell->dispatchShell('acl_extras', 'aco_sync');
        
        // or how the docs suggest
        // $shell->dispatchShell('shell_class', 'param1', 'param2');
    }

    /**
     * Edit method
     *
     * @param string|null $id Group id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $group = $this->Groups->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $group = $this->Groups->patchEntity($group, $this->request->getData());
            if ($this->Groups->save($group)) {
                $this->Flash->success(__('The group has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The group could not be saved. Please, try again.'));
        }
        $this->set(compact('group'));
        $this->set('title', 'Edit Group Name');

    }

    /**
     * Delete method
     *
     * @param string|null $id Group id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $group = $this->Groups->get($id);
        if ($this->Groups->delete($group)) {
            $this->Flash->success(__('The group has been deleted.'));
        } else {
            $this->Flash->error(__('The group could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }


    public function getControllers() {
        $files = scandir('../src/Controller/');
        $results = [];
        $ignoreList = [
            '.', 
            '..', 
            'Component', 
            'AppController.php',
            'ArosController.php',
            'PagesController.php',
            'PostsController.php',
            'ResourcesController.php'
        ];
        foreach($files as $file){
            if(!in_array($file, $ignoreList)) {
                $controller = explode('.', $file)[0];
                array_push($results, str_replace('Controller', '', $controller));
            }            
        }
        return $results;
    }


    public function getActions($controllerName) {

        $className = 'App\\Controller\\'.$controllerName.'Controller';

        $class = new \ReflectionClass($className);

        $actions = $class->getMethods(\ReflectionMethod::IS_PUBLIC);

        $results = [$controllerName => []];

        $ignoreList = ['beforeFilter', 'afterFilter', 'initialize', 'beforeRender'];

        foreach($actions as $action){
            if($action->class == $className && !in_array($action->name, $ignoreList)){
                array_push($results[$controllerName], $action->name);
            }
        }
        return $results;
    }

    public function editpermissions($id = null, $name = null) {
        $controllers = $this->getControllers();
        $resources = [];
        foreach($controllers as $controller){
            $actions = $this->getActions($controller);
            array_push($resources, $actions);
        }
        
        
        for($i = 1; $i < sizeof($resources); $i++) {
            $permission_arr = [];
            $actions_arr = [];
            foreach($resources[$i] as $controllerz => $actionsz) {
                
                for($j = 0; $j < sizeof($actionsz); $j++) {
                    $rs = $this->checkpermission($id, $controllerz, $actionsz[$j]);
                    // array_push($actions_arr, $actionsz[$j]);
                    if($rs == '1') {
                        $permission_chk = 'yes';
                        array_push($permission_arr, $permission_chk);
                    }   else   {
                        $permission_chk = 'no';
                        array_push($permission_arr, $permission_chk);
                    }
                }
                array_push($resources[$i], $permission_arr);
                
            }
        }
        unset($resources[0]);
        $tempArray = [];
        // pr($resources);die;
        $i=0;
        foreach ($resources as $value) {
            foreach ($value as $key => $value1) {
                //echo $key;
                if($key != '0'){
                    $controllerName = $key;
                    $count = count($value1);
                    for ($j=0; $j < $count ; $j++) { 
                        $tempArray[$i][$controllerName][$value1[$j]] = $value['0'][$j];
                    }
                }
            }
            $i++;
            # code...
        }
        // pr($tempArray);die;
        $this->set('resources', $tempArray);
        $this->set('group_id', $id);
        $this->set('group_name', $name);
        $this->set('title', 'Edit Groups Permissions');
        // return $resources;
    }

    public function allowpermission($grp = null, $ct = null, $act = null) {
        // pr($grp);
        // pr($ct);
        // pr($act);
        $page_url1 = $ct . "/" . $act;
        $rs = $this->checkpermission($grp, $ct, $act);
        if($rs == '1') {
            // $have_permission = 'yes';
            echo "Already have permission";
            $this->Flash->error(__('The group already have permission for this action.'));

        }   else   {
            
            if ($this->Acl->allow($grp, $page_url1)) {
                $this->Flash->success(__('Permission Assigned.'));
            } else {
                $this->Flash->error(__('The permission could not be assigned. Please, try again.'));
            }

            return $this->redirect(['action' => 'editpermissions', $grp]);



        }
        return null;
    }

    public function denypermission($group_id = null, $controller = null, $action = null) {
        $page_url = $controller . "/" . $action;
       
        $rs = $this->checkpermission($group_id, $controller, $action);
        if($rs != '1') {
            $this->Flash->error(__('The group already denied for this permission.'));

        }   else   {
            
            if ($this->Acl->deny($group_id, $page_url)) {
                $this->Flash->success(__('Permission Denied.'));
            } else {
                $this->Flash->error(__('The permission could not be denied. Please, try again.'));
            }
        }

            return $this->redirect(['action' => 'editpermissions', $group_id]);
    }

    public function checkpermission($group_id = null, $controller = null, $action = null) {
        $pu = "controllers/" . $controller . "/" .$action;
        $rafta = $this->Acl->check($group_id, $pu);
        // pr($rafta);die;
        return $rafta;
    }
}
