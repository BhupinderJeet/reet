<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header course_form-title">
                        <?php
                        if( isset( $data['result'] ) ) {
                            echo "<strong>Update Student</strong>";
                        }   else    {
                            echo "<strong>Create Student</strong>";
                        }
                        ?>
                    </div>
                    <div class="card-body card-block">
                       <?php $this->load->view('errors/alert'); ?> 
                        <?php
                            if( isset( $data['result'] ) ) {
                                echo form_open_multipart('students/add/'.$data['result']->id);
                            }   else  {
                                echo form_open_multipart('students/add');
                            }
                            
                        ?>
                        <div class="col-md-12">
                            <h6 class="fields_title">Course Details</h6>
                            <hr class="hori-line">
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <?php echo form_label('Course'); ?>
                                <?php
                                $selc = isset( $data['result'] ) ? $data['result']->course_id : "";
                                $options = [];
                                $key = [""];
                                $value = ["Select a Course"];
                                    foreach( $data['courses'] as $row ) :
                                        array_push($key, $row->id);
                                        array_push($value, $row->course_name);
                                    endforeach;
                                    $options = array_combine($key, $value);
                                    $arr = [
                                        'class' => form_error( 'course' ) ? 'input_red form-control course_listz' : "form-control course_listz", 
                                        'id' => 'course'
                                    ];
                                    echo form_dropdown('course', $options, $selc, $arr);
                                    echo form_error('course');
                                ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <?php echo form_label('Batch'); ?>
                                <?php
                                if( isset( $data['result'] ) ) {
                                    $options = [
                                        $data['result']->batch_id => $data['result']->batch_name
                                    ];
                                }   else  {
                                    $options = [
                                        '' => 'Select Batch',
                                    ];
                                }
                                    $arr = [
                                        'class' => form_error( 'batch' ) ? 'input_red form-control batch_listz' : 'form-control batch_listz', 
                                        'id' => 'batch'
                                    ];
                                    echo form_dropdown('batch', $options, '', $arr);
                                    echo form_error('batch');
                                ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <?php echo form_label('Admission Date'); ?>
                                <?php
                                    $adm = [
                                        'type' => 'text',
                                        'name' => 'admission_date',
                                        'placeholder' => 'Addmission Date',
                                        'class' => form_error( 'admission_date' ) ? 'input_red form-control datepicker' : 'form-control datepicker',
                                        'value' => isset($data['result']) ? $data['result']->admission_date : "",
                                        'data-provide' => 'datepicker'
                                    ];
                                    
                                    echo form_input($adm);
                                    echo form_error('admission_date');
                                ?>
                            </div>
                        </div>

                        <div class="col-md-12">
                           <h6 class="fields_title">Student Details</h6>
                            <hr class="hori-line">
                        </div>
                        <div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <?php
                                        echo form_label('Student Name', 'student_name');
                                        $sname = [
                                            'type' => 'text',
                                            'name' => 'student_name',
                                            'placeholder' => 'Student Name',
                                            'class' => form_error( 'student_name' ) ? 'input_red form-control' : 'form-control',
                                            'value' => isset( $data['result'] ) ? $data['result']->name : ""
                                        ];
                                        echo form_input($sname);
                                        echo form_error('student_name');
                                    ?>
                                </div>
                            </div>
                            <?php if( !isset($data['result']) ) { ?>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <?php
                                        echo form_label('Email', 'student_email');
                                        $semail = [
                                            'type' => 'email',
                                            'name' => 'student_email',
                                            'placeholder' => 'Email',
                                            'class' => form_error( 'student_email' ) ? 'input_red form-control' : 'form-control',
                                            'value' => ""
                                        ];
                                        echo form_input($semail);
                                        echo form_error('student_email');
                                    ?>
                                </div>
                            </div>
                            <?php } ?>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <?php
                                        echo form_label('Qualification', 'qualification');
                                        $qualif = [
                                            'type' => 'text',
                                            'name' => 'qualification',
                                            'placeholder' => 'Qualification',
                                            'class' => form_error( 'qualification' ) ? 'input_red form-control' : 'form-control',
                                            'value' => isset($data['result']->qualification) ? $data['result']->qualification : ""
                                        ];
                                        echo form_input($qualif);
                                        echo form_error('qualification');
                                    ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <?php
                                        echo form_label('Contact Number', 'contact_number');
                                        $scontact = [
                                            'type' => 'text',
                                            'name' => 'contact_number',
                                            'placeholder' => 'Contact Number',
                                            'class' => form_error( 'contact_number' ) ? 'input_red form-control' : 'form-control',
                                            'value' => isset( $data['result'] ) ? $data['result']->primary_contact : ""
                                        ];
                                        echo form_input($scontact);
                                        echo form_error('contact_number');
                                    ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <?php
                                        echo form_label('Alternate Contact', 'alternate_contact');
                                        $semail = [
                                            'type' => 'text',
                                            'name' => 'alternate_contact',
                                            'placeholder' => 'Alternate Contact',
                                            'class' => form_error( 'alternate_contact' ) ? 'input_red form-control' : 'form-control',
                                            'value' => isset($data['result']) ? $data['result']->alternate_contact : ""
                                        ];
                                        echo form_input($semail);
                                        echo form_error('alternate_contact');
                                    ?>
                                </div>
                            </div>
                             <div class="col-md-4">
                                <div class="form-group">
                                    <?php echo form_label('Upload Profile Picture'); ?>
                                    <?php
                                        $profile_pic = [
                                            'type' => 'file',
                                            'name' => 'profile_pic',
                                            'class' => form_error( 'profile_pic' ) ? 'input_red form-control form-control-file' : 'form-control form-control-file', 
                                            'id' => 'file-input'
                                        ];
                                        echo form_input($profile_pic);
                                        echo form_error('profile_pic');
                                        if( isset( $data['result'] ) ) {
                                    ?>
                                    <input type="hidden" name="hide_pic_name" value="<?php echo $data['result']->profile_pic; ?>">
                                    <?php
                                        }
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="form-group col-md-6">
                            <?php
                                echo form_label('Permanent Address', 'permanent_address');
                                $permanent_address = [
                                    'name' => 'permanent_address',
                                    'placeholder' => 'Permanent Address',
                                    'class' => form_error( 'permanent_address' ) ? 'input_red form-control' : 'form-control',
                                    'value' => isset($data['result']) ? $data['result']->permanent_address : "",
                                    'rows' => '3'
                                ];
                                echo form_textarea($permanent_address);
                                echo form_error('permanent_address');
                            ?>
                        </div>
                        <div class="form-group col-md-6">
                            <?php
                                echo form_label('Correspondence Address', 'local_address');
                                $l_address = [
                                    'name' => 'local_address',
                                    'placeholder' => 'Correspondence Address',
                                    'class' => form_error( 'local_address' ) ? 'input_red form-control' : 'form-control',
                                    'value' => isset($data['result']) ? $data['result']->local_address : "",
                                    'rows' => '3'
                                ];
                                echo form_textarea($l_address);
                                echo form_error('local_address');
                            ?>
                        </div>

                        <div class="col-md-12">
                           <h6 class="fields_title">Parent's Details</h6>
                            <hr class="hori-line">
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <?php
                                    echo form_label('Parents Name', 'parents_name');
                                    $pname = [
                                        'type' => 'text',
                                        'name' => 'parents_name',
                                        'placeholder' => 'Parents Name',
                                        'class' => form_error( 'parents_name' ) ? 'input_red form-control' : 'form-control',
                                        'value' => isset($data['result']) ? $data['result']->parent_name : ""
                                    ];
                                    echo form_input($pname);
                                    echo form_error('parents_name');
                                ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <?php
                                    echo form_label('Parents Contact', 'parents_contact');
                                    $pcontact = [
                                        'type' => 'text',
                                        'name' => 'parents_contact',
                                        'placeholder' => 'Parents Contact',
                                        'class' => form_error( 'parents_contact' ) ? 'input_red form-control' : 'form-control',
                                        'value' => isset($data['result']) ? $data['result']->parent_contact : ""
                                    ];
                                    echo form_input($pcontact);
                                    echo form_error('parents_contact');
                                ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <br />
                            <?php
                                $submit = [
                                    'name' => 'add_student_submit',
                                    'value' => isset($data['result']) ? 'Update' : 'Create',
                                    'class' => 'btn btn-info'
                                ];
                                echo form_submit($submit);
                                echo form_close();
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- .animated -->
</div><!-- .content -->
<script>
    $(document).ready(function() {
        $(".course_listz").on('change', function() {
            var course_id = $(".course_listz").val();
            
            $.ajax({
                url: "<?php echo base_url() ?>students/get_batches",
                type: 'POST',
                data: 'id='+course_id,
                dataType:'json',
                success: function(bat) {
                    var opt = '<option value="">Select Batch</option>';
                    if(bat.status == 'success'){
                        $.each(bat.data, function(index, item){
                            opt += '<option value="'+item.id+'">'+item.batch_name+'</option>';
                        })
                    }
                    $('select[name="batch"]').html(opt);
                },
                error: function() {
                    alert("Please reselect the course.");
                }
            });
            
        });
    });
</script>
