<div class="content mt-3">
    <div class="animated fadeIn">
    	<div class="row">
        	<div class="col-md-12">
        		<?php $this->load->view( 'errors/alert' ); ?>
        	</div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="student-detail-title">
                    <h3><?php echo $result->name ?></h3>
                </div>
            </div>
            <div class="col-md-4">
                <div class="student_picture">
                    <img src='<?php echo base_url() . "assets/images/students/" . $result->profile_pic ?>' class="img img-responsive">
                </div>
            </div>
            <div class="col-md-4">
                <div class="student-detail-col2">
                    <p>Name: <strong><?php echo $result->name; ?></strong></p>
                    <p>Course: <strong><?php echo $result->course_name; ?></strong></p>
                    <p>Batch: <strong><?php echo $result->batch_name; ?></strong> </p>
                    <p>Qualification: <strong><?php echo $result->qualification; ?></strong></p>
                    <p>Admission Date: <strong><?php echo $result->admission_date; ?></strong></p>
                    <p>Parent's Name: <?php echo $result->parent_name; ?></p>
                    <p>Parent's Contact: <?php echo $result->parent_contact; ?></p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="student-detail-col3">
                    <p>Contact Number: <strong><?php echo $result->primary_contact; ?></strong></p>
                    <p>Alternate Contact: <strong><?php echo $result->alternate_contact; ?></strong></p>
                    <p>Permanent Address: <strong><?php echo $result->permanent_address; ?></strong></p>
                    <p>Correspondence Address: <strong><?php echo $result->local_address; ?></strong></p>
                </div>
            </div>
        </div>
    </div>
</div>