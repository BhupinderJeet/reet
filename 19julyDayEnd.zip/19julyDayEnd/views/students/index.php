<div class="content mt-3">
    <div class="animated fadeIn">
    	<div class="row">
        	<div class="col-md-12">
        		<?php $this->load->view( 'errors/alert' ); ?>
        	</div>
        </div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
				    <div class="card-header">
				        <strong class="card-title">Students List</strong>
				        <?php
				        echo anchor('students/add', 'Add Student', ['class' => 'btn btn-info pull-right'])
				        ?>
				    </div>
				    <div class="card-body">
						<table id="bootstrap-data-table" class="table table-striped table-bordered">
							<thead>
							  <tr>
							    <th>Student Name</th>
							    <th>Course Name</th>
							    <th>Batch</th>
							    <th>Actions</th>
							  </tr>
							</thead>
							<tbody>
								<?php foreach( $data as $row ): ?>
								<tr>
									<td><?php echo $row->name; ?></td>
									<td><?php echo $row->course_name; ?></td>
									<td><?php echo $row->batch_name; ?></td>
									<td>
										<?php
										echo anchor( 'students/student_details/'.$row->id, ' <i class="fa fa-eye"></i> ', ['class' => 'badge badge-success left-space_a', 'title' => 'Student Details'] );
										echo anchor( 'students/add/'.$row->id, ' <i class="fa fa-edit"></i> ', ['class' => 'badge badge-info left-space_a', 'title' => 'Edit'] );
										echo anchor('students/delete/'.$row->id, ' <i class="fa fa-trash"></i> ', ['class' => 'badge badge-danger left-space_a', 'title' => 'Delete', 'onclick' => 'return deletecheck();']);
										?>
									</td>
								</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
			    	</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	function deletecheck() {
		if(confirm('Delete Selected Course?')) {
			return true;
		}	else {
			return false;
		}
	}
</script>
