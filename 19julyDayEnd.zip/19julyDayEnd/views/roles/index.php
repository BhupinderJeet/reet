<div class="content mt-3">
    <div class="animated fadeIn">
    	<div class="row">
        	<div class="col-md-12">
        		<?php $this->load->view( 'errors/alert' ); ?>
        	</div>
        </div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
				    <div class="card-header">
				        <strong class="card-title">Roles List</strong>
				        <span style="float: right;">
					        <?php
					        echo anchor( 'roles/add', 'Add Role', ['class' => 'btn btn-info'] );
					        ?>
					    </span>
				    </div>
				    <div class="card-body">
						<table id="bootstrap-data-table" class="table table-striped table-bordered">
							<thead>
								<tr>
									<th>Role's Name</th>
									<th>Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach( $result as $row ): ?>
								<tr>
									<td><?php echo $row->role_name; ?></td>
									<td>
										<?php
										echo anchor('roles/add/'.$row->id, ' <i class="fa fa-edit"></i> ', ['class' => 'badge badge-info left-space_a', 'title' => 'Edit']);
										//echo anchor('roles/delete/'.$row->id, ' <i class="fa fa-trash"></i> ', ['class' => 'badge badge-danger left-space_a', 'title' => 'Delete', 'onclick' => 'return deletecheck();']);
										?>
									</td>
								</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
			    	</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	function deletecheck() {
		if(confirm('Delete Selected Role?')) {
			return true;
		}	else {
			return false;
		}
	}
</script>
