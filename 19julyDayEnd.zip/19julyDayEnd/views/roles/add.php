<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header course_form-title">
                        <?php 
                        if( isset( $data ) ) {
                            echo "<strong>Update Role</strong>";
                        }   else    {
                            echo "<strong>Create New Role</strong>";
                        }

                        ?>
                    </div>
                    <div class="card-body card-block">
                        <?php
                            $this->load->view( 'errors/alert' );
                            if( isset( $data ) ) {
                                echo form_open( 'roles/add/'.$data['id'] );
                            }   else    {
                                echo form_open( 'roles/add' );
                            }
                        ?>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php
                                    echo form_label( 'Role Name', 'role_name' );
                                    $role_name = [
                                        'type' => 'text',
                                        'name' => 'role_name',
                                        'placeholder' => 'Role Name',
                                        'class' => form_error('role_name') ? 'input_red form-control' : 'form-control',
                                        'value' => isset( $data ) ? $data['role_name'] : ""
                                    ];
                                    echo form_input( $role_name );
                                    echo form_error('role_name')
                                ?>
                            </div>
                        </div>
                        
                        <div class="col-md-12">
                            <br />
                            <?php
                            if( isset( $data ) ){
                                $submit = [
                                    'name' => 'Edit_role_submit',
                                    'value' => 'Update',
                                    'class' => 'btn btn-info'
                                ];
                            }   else    {
                                $submit = [
                                    'name' => 'add_role_submit',
                                    'value' => 'Create',
                                    'class' => 'btn btn-info'
                                ];
                            }
                                
                                echo form_submit($submit);
                                echo form_close();
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- .animated -->
</div><!-- .content -->