<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header course_form-title">
                        <strong>Create Freelancers</strong>
                    </div>
                    <div class="card-body card-block">
                        <?php
                            $this->load->view( 'errors/alert' );
                            echo validation_errors();
                            echo form_open_multipart('freelancers/add');
                        ?>
                        <table id="bootstrap-data-table" class="table table-striped table-bordered">
                            <thead>
                              <tr>
                                <th><input type="checkbox" name="all_std[]" value="select_all" id="checkAll" class="check"><label> All</label>
                                <th>Student Name</th>
                                <th>Course Name</th>
                                <th>Batch</th>
                                <th>Email</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php foreach( $students as $student ): ?>
                                <tr>
                                    <td><input type="checkbox" name="student_list[]" value="<?php echo $student->id; ?>" class="check"></td>
                                    <td><?php echo $student->name; ?></td>
                                    <td><?php echo $student->course_name; ?></td>
                                    <td><?php echo $student->batch_name; ?></td>
                                    <td><?php echo $student->email; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>                      
                        <div class="col-md-12">
                            <br />
                            <?php
                                $submit = [
                                    'name' => 'add_freelancer_submit',
                                    'value' => 'Create Freelancer(s)',
                                    'class' => 'btn btn-info'
                                ];
                                echo form_submit($submit);
                                echo form_close();
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- .animated -->
</div><!-- .content -->
<script>
$("#checkAll").click(function () {
    $(".check").prop('checked', $(this).prop('checked'));
});
</script>