<?php if( $flash = $this->session->flashdata('flash' )) { ?>
<div class='alert alert-<?php echo $flash['type'] ?>'>
<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
<i class="fa <?php echo $flash['icon'] ?>"></i> <?php echo $flash['message']; ?>
</div>
<?php } ?>
