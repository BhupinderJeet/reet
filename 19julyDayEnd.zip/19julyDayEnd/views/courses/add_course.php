<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header course_form-title">
                        <?php if( !isset( $course ) ) { ?>
                        <strong>Create New Course</strong>
                        <?php } else { ?>
                        <strong>Update Course</strong>
                        <?php } ?>
                    </div>
                    <div class="card-body card-block">
                        <?php
                            $this->load->view( 'errors/alert' );
                            if( isset( $course ) ) {
                                $pathh = "/" . $course->id;
                            }   else {
                                $pathh = "";
                            }
                            echo form_open('courses/add_course/' . $pathh);
                        ?>
                        <div class="col-md-4">
                            <div class="form-group">
                                <?php
                                    echo form_label('Course Name', 'course_name');
                                    $cname = [
                                        'type' => 'text',
                                        'name' => 'course_name',
                                        'placeholder' => 'Course Name',
                                        'class' => form_error('course_name') ? 'input_red form-control' : 'form-control',
                                        'value' => isset( $course ) ? $course->course_name : ""
                                    ];
                                    echo form_input($cname);
                                    echo form_error('course_name');
                                ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <?php echo form_label('Course Type'); ?>
                                    </div>
                                    <div class="col-md-5">
                                    <?php
                                        
                                        if( isset( $course ) ) {
                                            $selc = $course->course_type;
                                        }   else    {
                                            $selc = "";
                                        }
                                        $options = [
                                            'days' => 'Days',
                                            'weeks' => 'Weeks',
                                            'months' => 'Months',
                                            'years' => 'Years'
                                        ];
                                        $arr = [
                                            'class' => form_error('course_type') ? 'input_red form-control' : 'form-control', 
                                            'id' => 'course_type'
                                        ];
                                        echo form_dropdown('course_type', $options, $selc, $arr);
                                        echo form_error('course_type');
                                    ?>
                                    </div>
                                    <div class="col-md-7">
                                    <?php
                                        /****/
                                        $dur = [
                                            'type' => 'number',
                                            'name' => 'course_duration',
                                            'placeholder' => 'Duration',
                                            'class' => form_error('course_duration') ? 'input_red form-control' : 'form-control',
                                            'value' => isset( $course ) ? $course->course_duration : ''
                                        ];
                                        echo form_input($dur);
                                        echo form_error( 'course_duration' );
                                    ?>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <?php
                                    echo form_label('Course Fee', 'course_fee');
                                    $cname = [
                                        'type' => 'number',
                                        'name' => 'course_fee',
                                        'placeholder' => 'Course Fee',
                                        'class' => form_error('course_fee') ? 'input_red form-control' : 'form-control',
                                        'value' => isset( $course ) ? $course->course_fee : ""
                                    ];
                                    echo form_input($cname);
                                    echo form_error('course_fee');
                                ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php
                                    echo form_label('Course Description', 'course_description');
                                    $desc = [
                                        'name' => 'course_description',
                                        'placeholder' => 'Course Description',
                                        'value' => isset( $course ) ? $course->description : ''
                                    ];
                                    $attr = [
                                        'class' => form_error('username') ? 'input_red form-control ckeditor' : 'form-control ckeditor'
                                    ];
                                    echo form_textarea($desc, '', $attr);
                                    echo form_error('course_description');
                                ?>
                            </div>
                        </div>
                        
                        <div class="col-md-12">
                            <br />
                            <?php
                                $submit = [
                                    'name' => 'add_course_submit',
                                    'value' => isset( $course ) ? 'Update' : 'Create',
                                    'class' => 'btn btn-info'
                                ];
                                echo form_submit($submit);
                                echo form_close();
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- .animated -->
</div><!-- .content -->