<div class="content mt-3">
    <div class="animated fadeIn">
    	<div class="row">
        	<div class="col-md-12">
        		<?php $this->load->view( 'errors/alert' ); ?>
        	</div>
        </div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
				    <div class="card-header">
				        <strong class="card-title">Courses List</strong>
				        <span style="float: right;">
					        <?php
					        echo anchor( 'courses/add_course', 'Add Course', ['class' => 'btn btn-info'] );
					        ?>
					    </span>
				    </div>
				    <div class="card-body">
						<table id="bootstrap-data-table" class="table table-striped table-bordered">
							<thead>
							  <tr>
							    <th>Course Name</th>
							    <th>Course Duration</th>
							    <th>Batches</th>
							    <th>Topics</th>
							    <th>Actions</th>
							  </tr>
							</thead>
							<tbody>
								<?php foreach( $result as $row ): ?>
								<tr>
									<td><?php echo $row->course_name; ?></td>
									<td class="text_capit"><?php echo $row->course_duration . " " . $row->course_type; ?></td>
									<td>
										<?php
										echo anchor( 'batches/index/'.$row->id, ' <i class="fa fa-eye"></i> ', ['class' => 'badge badge-success left-space_a', 'title' => 'View Batches'] );
										echo anchor( 'batches/add/'.$row->id, ' <i class="fa fa-plus"></i> ', ['class' => 'badge badge-info left-space_a', 'title' => 'Add New Batch'])
										?>
									</td>
									<td>
										<?php
										echo anchor('topics/course_topics/'.$row->id, ' <i class="fa fa-eye"></i> ', ['class' => 'badge badge-success left-space_a', 'title' => 'View Topics'] );
										echo anchor( 'topics/add_topic/'.$row->id, ' <i class="fa fa-plus"></i> ', ['class' => 'badge badge-primary left-space_a', 'title' => 'Add Topic', 'target' => '_blank'] );
										?>
									</td>
									<td>
										<?php
										echo anchor('courses/add_course/'.$row->id, ' <i class="fa fa-edit"></i> ', ['class' => 'badge badge-info left-space_a', 'title' => 'Edit']);
										echo anchor('courses/delete/'.$row->id, ' <i class="fa fa-trash"></i> ', ['class' => 'badge badge-danger left-space_a', 'title' => 'Delete', 'onclick' => 'return deletecheck();']);
										?>
									</td>
								</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
			    	</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	function deletecheck() {
		if(confirm('Delete Selected Course?')) {
			return true;
		}	else {
			return false;
		}
	}
</script>
