<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header course_form-title">
                        <strong>Update Batch :  <?php echo $data['result']->batch_name; ?></strong>
                     </div>
                    <div class="card-body card-block">
                        <?php
                            $this->load->view( 'errors/alert' );
                            echo form_open( 'batches/edit/'.$data['id'] );
                        ?>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php
                                    echo form_label('Batch Name', 'batch_name');
                                    $batch_name = [
                                        'type' => 'text',
                                        'name' => 'batch_name',
                                        'placeholder' => 'Batch Name',
                                        'class' => form_error('batch_name') ? 'input_red form-control' : 'form-control',
                                        'value' => isset($data['result']) ? $data['result']->batch_name : ""
                                    ];
                                    echo form_input($batch_name);
                                    echo form_error('batch_name');
                                ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo form_label( 'Start Date', 'start_date' ); ?>
                                <?php
                                    $start_date = [
                                        'name' => 'start_date',
                                        'class' => form_error('start_date') ? 'input_red form-control datepicker' : 'form-control datepicker', 
                                        'id' => 'start_date',
                                        'placeholder' => 'mm/dd/yyyy',
                                        'data-provide' => 'datepicker',
                                        'value' => isset($data['result']) ? $data['result']->start_date : ""
                                    ];
                                    echo form_input( $start_date );
                                    echo form_error('start_date');
                                ?>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <?php echo form_label( 'End Date', 'end_date' ); ?>
                                <?php
                                    $end_date = [
                                        'name' => 'end_date',
                                        'class' => form_error('end_date') ? 'input_red form-control datepicker' : 'form-control datepicker', 
                                        'id' => 'end_date',
                                        'placeholder' => 'mm/dd/yyyy',
                                        'data-provide' => 'datepicker',
                                        'value' => isset($data['result']) ? $data['result']->end_date : ""
                                    ];
                                    echo form_input($end_date);
                                    echo form_error('end_date');
                                ?>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <br />
                            <?php
                                $submit = [
                                    'name' => 'edit_batch',
                                    'value' => 'Update',
                                    'class' => 'btn btn-info'
                                ];
                                echo form_submit($submit);
                                echo form_close();
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- .animated -->
</div><!-- .content -->
<script type="text/javascript">
    $(".datepicker").datepicker({
        autoclose : 'true',
        format : 'yyyy/mm/dd'
    });
</script>