<div class="content mt-3">
    <div class="animated fadeIn">
    	<div class="row">
        	<div class="col-md-12">
        		<?php $this->load->view( 'errors/alert' ); ?>
        	</div>
        </div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
				    <div class="card-header">
				        <strong class="card-title">Batches List ( <?php echo $course_name; ?> )</strong>
				        <?php
				        echo anchor('batches/add/'.$cr_id, 'New Batch', ['class' => 'btn btn-info pull-right'])
				        ?>
				    </div>
				    <div class="card-body">
						<table id="bootstrap-data-table" class="table table-striped table-bordered">
							<thead>
							  <tr>
							    <th>Batch Name</th>
							    <th>Start Date</th>
							    <th>End Date</th>
							    <th>Actions</th>
							  </tr>
							</thead>
							<tbody>
								<?php foreach( $result as $row ): ?>
								<tr>
									<td><?php echo $row->batch_name; ?></td>
									<td><?php echo $row->start_date; ?></td>
									<td><?php echo $row->end_date; ?></td>
									<td>
										<?php
										echo anchor( 'batches/edit/'.$row->id, ' <i class="fa fa-edit"></i> ', ['class' => 'badge badge-info left-space_a', 'title' => 'Edit'] );
										echo anchor('batches/delete/'.$row->id, ' <i class="fa fa-trash"></i> ', ['class' => 'badge badge-danger left-space_a', 'title' => 'Delete', 'onclick' => 'return deletecheck();']);
										?>
									</td>
								</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
			    	</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	function deletecheck() {
		if(confirm('Delete Selected Course?')) {
			return true;
		}	else {
			return false;
		}
	}
</script>
