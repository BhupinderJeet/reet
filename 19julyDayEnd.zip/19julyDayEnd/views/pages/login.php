<div class="sufee-login d-flex align-content-center flex-wrap">
    <div class="container">
        <div class="login-content">
            <div class="login-form">
                <?php
                if( $this->session->flashdata('success' ) != "" ) {
                ?>
                    <div class='alert alert-success'>
                        <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                        <?php
                            echo $this->session->flashdata('success');
                        ?>
                    </div>
                <?php
                }
                if( $this->session->flashdata('error' ) != "" ) {
                ?>
                    <div class='alert alert-danger'>
                        <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                        <?php
                            echo $this->session->flashdata('error');
                        ?>
                    </div>
                <?php
                }
                ?>
                <?php
                    $this->load->view( 'errors/alert' );
                    echo form_open( 'login' ); 
                ?>
                <div class="form-group">
                    <?php echo form_label( 'Email Address', 'username' ); ?>
                    <?php
                        $email = [
                            'type' => 'email',
                            'class' => form_error('username') ? 'input_red form-control' : 'form-control',
                            'placeholder' => 'Email',
                            'name' => 'username',
                            'value' => set_value( 'username' )
                        ];
                     
                        echo form_input($email);
                        echo form_error('username');
                    ?>
                </div>
                <div class="form-group">
                    <?php
                        echo form_label('Password', 'password');

                        $pass = [
                            'type' => 'password',
                            'class' => form_error('password') ? 'input_red form-control' : 'form-control',
                            'placeholder' => 'Password',
                            'name' => 'password',
                            'value' => set_value( 'password' )
                        ];
                        echo form_input($pass);
                        echo form_error('password');
                    ?>

                </div>
                <div class="checkbox">
                    <?php
                        $remember = [
                            'name' => 'rember_password'
                        ];
                        echo form_checkbox($remember) . " Remember Me"; 
                    ?>
                    <!-- <label class="pull-right">
                        <a href="#">Forgotten Password?</a>
                    </label> -->
                </div>
                <?php
                    $submit = [
                        'name' => 'login',
                        'value' => 'Sign in',
                        'class' => 'btn btn-success btn-flat m-b-30 m-t-30'
                    ];
                    echo form_submit($submit);
                    echo form_close(); 
                ?>
            </div>
        </div>
    </div>
</div>


