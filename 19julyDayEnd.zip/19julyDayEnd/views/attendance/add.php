<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header course_form-title">
                        <strong>Create Attendance</strong>
                    </div>
                    <div class="card-body card-block">
                       <?php $this->load->view('errors/alert'); ?> 
                        <?php
                            echo form_open('attendance/add');
                        ?>
                        <div class="col-md-4">
                            <div class="form-group">
                                <?php echo form_label('Course'); ?>
                                <?php
                                $options = [];
                                $key = [""];
                                $value = ["Select a Course"];
                                    foreach( $courses as $row ) :
                                        array_push($key, $row->id);
                                        array_push($value, $row->course_name);
                                    endforeach;
                                    $options = array_combine($key, $value);
                                    $arr = [
                                        'class' => form_error( 'course' ) ? 'input_red form-control course_listz' : "form-control course_listz", 
                                        'id' => 'course'
                                    ];
                                    echo form_dropdown('course', $options, '', $arr);
                                    echo form_error('course');
                                ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <?php echo form_label('Batch'); ?>
                                <?php
                                if( isset( $data['result'] ) ) {
                                    $options = [
                                        $data['result']->batch_id => $data['result']->batch_name
                                    ];
                                }   else  {
                                    $options = [
                                        '' => 'Select Batch',
                                    ];
                                }
                                    $arr = [
                                        'class' => form_error( 'batch' ) ? 'input_red form-control batch_listz' : 'form-control batch_listz', 
                                        'id' => 'batch'
                                    ];
                                    echo form_dropdown('batch', $options, '', $arr);
                                    echo form_error('batch');
                                ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <?php echo form_label('Atendence Date'); ?>
                                <?php
                                    $attendance_date = [
                                        'type' => 'text',
                                        'name' => 'attendance_date',
                                        'placeholder' => 'Attendance Date',
                                        'class' => form_error( 'attendance_date' ) ? 'input_red form-control attendance_date datepicker' : 'form-control attendance_date datepicker',
                                        'data-provide' => 'datepicker',
                                        'value' => date('m/d/Y')
                                    ];
                                    
                                    echo form_input($attendance_date);
                                    echo form_error('attendance_date');
                                ?>
                            </div>
                        </div>
                        <div class="col-md-1">
                            <div class="form-group fetch_btn">
                                <button class="btn btn-info" type="button" id="students_attn">Go</button>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <hr>
                        </div>
                <!-- ****************List Students below.*****************  -->
                        <div class="col-md-12">
                            <div class="student_list" id="student_attendance_list">

                            </div>
                        </div>
                        
                        <div class="col-md-12">
                            <br />
                            <?php
                                $submit = [
                                    'name' => 'add_student_submit',
                                    'value' => isset($data['result']) ? 'Update' : 'Create',
                                    'class' => 'btn btn-info'
                                ];
                                echo form_submit($submit);
                                echo form_close();
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- .animated -->
</div><!-- .content -->
<script>
    $(document).ready(function() {
        $(".course_listz").on('change', function() {
            var course_id = $(".course_listz").val();
            
            $.ajax({
                url: "<?php echo base_url(); ?>students/get_batches",
                type: 'POST',
                data: 'id='+course_id,
                dataType:'json',
                success: function(bat) {
                    var opt = '<option value="">Select Batch</option>';
                    if(bat.status == 'success'){
                        $.each(bat.data, function(index, item){
                            opt += '<option value="'+item.id+'">'+item.batch_name+'</option>';
                        })
                    }
                    $('select[name="batch"]').html(opt);
                },
                error: function() {
                    alert("Please reselect the course.");
                }
            });
        });
        

        // **********  get students for attendance as selected course and batch
        $('#students_attn').on('click', function(event) {
            var att_date = $(".attendance_date").val();
           var course_id = $(".course_listz").val();
            var batch_id = $('.batch_listz').val();
            $.ajax({
                url: "<?php echo base_url(); ?>attendance/attendance_students",
                type: 'POST',
                data: {c_id:course_id, b_id:batch_id, atnd_date:att_date},
                dataType:'html',
                success: function(students) {
                    $('#student_attendance_list').html(students);
                },
                error: function(xhr, status, error) {
                    console.log(xhr.responseText);
                }
            });
        });
    });
</script>
