<div class="card">
    <div class="card-header">
        <strong class="card-title">Students List</strong>
    </div>
    <div class="card-body">
		<table id="bootstrap-data-table" class="table table-striped table-bordered">
			<thead>
			  <tr>
			    <th>Student Name / Email</th>
			    <th>Actions</th>
			  </tr>
			</thead>
			<tbody>
				<?php
					$student_count = 0;
					foreach( $result as $row ):
					$student_count++;
				?>
				<tr>
					<td><?php echo $row->name . "  (" . $row->email . ")"; ?></td>
					<td>
						<?php
						if( $row->status != null ) {
							$sel = $row->status;
						}	else {
							$sel = "";
						}
						
						$options = [
							'0' => 'Absent',
							'1' => 'Present'
						];
						$arr = [
                                'class' => form_error( 'attendance_mark'.$student_count ) ? 'input_red form-control' : "form-control"
                            ];
                            echo form_dropdown('attendance_mark'.$student_count, $options, $sel, $arr);
                            echo form_error('attendance_mark'.$student_count);
						?>
						<input type="hidden" name="student_id<?php echo $student_count; ?>" value="<?php echo $row->id; ?>">
						<input type="hidden" name="user_id<?php echo $student_count; ?>" value="<?php echo $row->user_id; ?>">
						<input type="hidden" name="attendance_id<?php echo $student_count; ?>" value="<?php echo $row->att_id; ?>">
					</td>
				</tr>
				<?php endforeach; ?>
				<input type="hidden" name="student_count" value="<?php echo $student_count; ?>">
			</tbody>
		</table>
	</div>
</div>
