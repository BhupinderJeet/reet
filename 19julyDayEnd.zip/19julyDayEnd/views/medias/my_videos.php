<div class="content mt-3">
    <div class="animated fadeIn">
    	<div class="row">
        	<div class="col-md-12">
        		<?php $this->load->view( 'errors/alert' ); ?>
        	</div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="student-detail-title">
                    <div class="row">
                        <div class="col-md-6">
                            <h3>Your Videos</h3>
                        </div>
                        <div class="col-md-6">
                            <?php
                                echo anchor('medias/add', 'Add Video Links', ['class' => 'btn btn-info pull-right']);
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php foreach ( $videos as $video ) : ?>
            <div class="col-md-4">
                <?php echo html_entity_decode($video->link); ?>
            </div>
        <?php endforeach; ?>
        </div>
    </div>
</div>
<style type="text/css">
    iframe {
        width: 100% !important;
    }
</style>