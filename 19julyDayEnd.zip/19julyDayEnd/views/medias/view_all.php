<div class="content mt-3">
    <div class="animated fadeIn">
    	<div class="row">
        	<div class="col-md-12">
        		<?php $this->load->view( 'errors/alert' ); ?>
        	</div>
        </div>
        <div class="row" id="admin_body">
            <div class="col-md-12">
                <div class="student-detail-title">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-6">
                            <h3>All Videos</h3>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-6">
                            <?php
                                echo anchor('medias/add', 'Add Video Links', ['class' => 'btn btn-info pull-right']);
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php 
            $count = 1;
            foreach ( $videos as $video ) : 
            ?>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="video_block_container">
                        <div class="iframe_holder">
                            <div class="iframe_block_overlay">
                                <a href="#" class="btn btn-info" data-toggle="modal" data-target="#my_video<?php echo $count; ?>">Open video</a>
                            </div>
                            <?php echo html_entity_decode( $video->link ); ?>
                        </div>
                        <div class="video_details">
                            <hr>
                            <strong class="pull-left"><?php echo $video->name; ?></strong>
                            <small class="pull-right"><?php echo $video->created; ?></small>
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="my_video<?php echo $count; ?>" role="dialog">
                    <div class="modal-dialog modal-lg">

                    <!-- Modal content-->
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title pull-left"><?php echo $video->name; ?></h4>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                            <div class="modal-body">
                                <?php echo html_entity_decode( $video->link ); ?>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                            </div>
                        </div>

                    </div>
                </div>

            <?php 
            $count++;
            endforeach; 
            ?>
        </div>
    </div>
</div>
<style type="text/css">
    iframe {
        width: 100% !important;
        height: 190px !important;
        position: relative !important;
    }
    .iframe_holder {
        position: relative;
        width: 100%;
        height: auto;
        
    }
    .iframe_block_overlay {
        transition: 0.4s;
        display: none;
    }
    .iframe_holder:hover .iframe_block_overlay {
        display: block;
        position: absolute;
        height: 96%;
        width: 100%;
        top: 0;
        left: 0;
        background: rgba(0,119,190,0.4);
        z-index: 9;
    }
    .iframe_block_overlay a {
        margin: 25% 32%;
    }
    .modal-backdrop.fade.show {
        display: none;
    }
    .modal-backdrop.fade.in {
        display: none;
    }
    .modal.fade.show.in {
        background: rgba(0,0,0,0.7);
    }
</style>