<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row" id="admin_body">
            <div class="col-md-12">
                <div class="">
                    <div class="card-header course_form-title">
                        <?php 
                        if( isset( $data ) ) {
                            echo "<strong>Update Video Link</strong>";
                        }   else    {
                            echo "<strong>Create New Video Link</strong>";
                        }

                        ?>
                    </div>
                    <div class="card-body card-block">
                        <?php
                            $this->load->view( 'errors/alert' );
                            if( isset( $data ) ) {
                                echo form_open( 'medias/add/'.$data['id'] );
                            }   else    {
                                echo form_open( 'medias/add' );
                            }
                        ?>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php
                                    echo form_label( 'Add Link', 'add_link' );
                                    $video_link = [
                                        'name' => 'add_link',
                                        'placeholder' => 'Add Link',
                                        'value' => ''
                                    ];
                                    $attr = [
                                        'class' => form_error('add_link') ? 'input_red form-control' : 'form-control'
                                    ];
                                    echo form_textarea($video_link, '', $attr);
                                    echo form_error('add_link');
                                ?>
                            </div>
                        </div>
                        
                        <div class="col-md-12">
                            <br />
                            <?php
                            if( isset( $data ) ){
                                $submit = [
                                    'name' => 'update_role_submit',
                                    'value' => 'Update',
                                    'class' => 'btn btn-info'
                                ];
                            }   else    {
                                $submit = [
                                    'name' => 'add_link_submit',
                                    'value' => 'Create',
                                    'class' => 'btn btn-info'
                                ];
                            }
                                
                                echo form_submit($submit);
                                echo form_close();
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- .animated -->
</div><!-- .content -->