<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header course_form-title">
                        <strong>Change Password</strong>
                    </div>
                    <div class="card-body card-block">
                        <?php
                            $this->load->view('errors/alert');

                            echo form_open( 'login/verify_account/'.$data['token'] );
                        ?>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php
                                    echo form_label( 'Old Password', 'old_password' );
                                    $old_pass = [
                                        'type' => 'text',
                                        'name' => 'old_password',
                                        'placeholder' => 'Old Password',
                                        'class' => form_error( 'old_password' ) ? 'input_red form-control' : 'form-control',
                                        'value' => ( $data['form_data'] != "" ) ? $data['form_data']['old_password'] : ""
                                    ];
                                    echo form_input( $old_pass );
                                    echo form_error('old_password');
                                ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php
                                    echo form_label( 'New Password', 'new_password' );
                                    $new_password = [
                                        'type' => 'text',
                                        'name' => 'new_password',
                                        'placeholder' => 'New Password',
                                        'class' => form_error( 'new_password' ) ? 'input_red form-control' : 'form-control',
                                        'value' => ( $data['form_data'] != "" ) ? $data['form_data']['new_password'] : ""
                                    ];
                                    echo form_input( $new_password );
                                    echo form_error('new_password');
                                ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php
                                    echo form_label( 'Confirm Password', 'confirm_pass' );
                                    $confirm_password = [
                                        'type' => 'text',
                                        'name' => 'confirm_password',
                                        'placeholder' => 'Confirm Password',
                                        'class' => form_error( 'confirm_password' ) ? 'input_red form-control' : 'form-control',
                                        'value' => ( $data['form_data'] != "" ) ? $data['form_data']['confirm_password'] : ""
                                    ];
                                    echo form_input( $confirm_password );
                                    echo form_error('confirm_password');
                                ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <br />
                            <?php
                                $submit = [
                                    'name' => 'change_pass_submit',
                                    'value' => 'Change Password',
                                    'class' => 'btn btn-info'
                                ];
                                echo form_submit($submit);
                                echo form_close();
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- .animated -->
</div><!-- .content -->