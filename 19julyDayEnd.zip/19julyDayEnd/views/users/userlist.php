<div class="content mt-3">
    <div class="animated fadeIn">
    	<div class="row">
        	<div class="col-md-12">
        		<?php $this->load->view( 'errors/alert' ); ?>
        	</div>
        </div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
				    <div class="card-header">
				        <strong class="card-title">Users List</strong>
				    </div>
				    <div class="card-body">
						<table id="bootstrap-data-table" class="table table-striped table-bordered">
							<thead>
							  <tr>
							    <th>Email</th>
							    <th>Role</th>
							    <th>Account Status</th>
							    <th>Creation Date</th>
							    <th>Actions</th>
							  </tr>
							</thead>
							<tbody>
								<?php foreach( $result as $row ): ?>
								<tr>
									<td><?php echo $row->email; ?></td>
									<td><?php echo $row->role_name; ?></td>
									<td>
										<?php
										if( $row->status == 1 ) {
											echo "Verified";
										}	else 	{
											echo "Not Verified";
										}
										?>
									</td>
									<td><?php echo $row->created; ?></td>
									<td>
										<?php
										echo anchor( 'users/edit/'.$row->id, ' <i class="fa fa-edit"></i> ', ['class' => 'badge badge-info left-space_a', 'title' => 'Edit'] );
										echo anchor('users/delete/'.$row->id, ' <i class="fa fa-trash"></i> ', ['class' => 'badge badge-danger left-space_a', 'title' => 'Delete', 'onclick' => 'return deletecheck();']);
										?>
									</td>
								</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
			    	</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	function deletecheck() {
		if(confirm('Delete Selected Course?')) {
			return true;
		}	else {
			return false;
		}
	}
</script>
