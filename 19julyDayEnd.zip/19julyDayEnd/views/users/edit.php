<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header course_form-title">
                        <strong>Add New User</strong>
                    </div>
                    <div class="card-body card-block">
                        <?php
                            $this->load->view( 'errors/alert' );
                            echo form_open( 'users/add' );
                        ?>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php
                                    echo form_label( 'Username', 'username' );
                                    $user_name = [
                                        'type' => 'email',
                                        'name' => 'username',
                                        'placeholder' => 'Username',
                                        'class' => form_error( 'username' ) ? 'input_red form-control' : 'form-control',
                                        'value' => ""
                                    ];
                                    echo form_input( $user_name );
                                    echo form_error('username');
                                ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php
                                    echo form_label( 'Password', 'password' );
                                    $password = [
                                        'type' => 'text',
                                        'name' => 'password',
                                        'placeholder' => 'Password',
                                        'class' => form_error( 'password' ) ? 'input_red form-control' : 'form-control',
                                        'value' => ""
                                    ];
                                    echo form_input( $password );
                                    echo form_error('password');
                                ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php
                                    echo form_label( 'Role', 'role' );
                                    $options = [];
                                    $key = [""];
                                    $value = ["Select a Role"];
                                    foreach( $data['roles'] as $role ) {
                                        array_push( $key, $role->id );
                                        array_push( $value, $role->role_name );
                                    }
                                    $options = array_combine( $key, $value );
                                    $attr = [
                                        'class' => form_error( 'role' ) ? 'input_red form-control' : 'form-control',
                                        'id' => "role"
                                    ];
                                    echo form_dropdown( 'role', $options, '', $attr );
                                    echo form_error('role');
                                ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <br />
                            <?php
                                $submit = [
                                    'name' => 'edit_user_submit',
                                    'value' => 'Create',
                                    'class' => 'btn btn-info'
                                ];
                                echo form_submit($submit);
                                echo form_close();
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- .animated -->
</div><!-- .content -->