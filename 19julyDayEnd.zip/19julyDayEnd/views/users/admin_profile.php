<div class="content mt-3">
    <div class="animated fadeIn">
    	<div class="row">
        	<div class="col-md-12">
        		<?php $this->load->view( 'errors/alert' ); ?>
        	</div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="student-detail-title">
                    <div class="row">
                        <div class="col-md-12">
                            <h3>ADMIN ACCOUNT</h3>
                        </div>
                        
                    </div>
                </div>
            </div>
            
            <div class="col-md-12">
                <div class="student-detail-col3">
                    <p>Registered Email: <strong><?php echo $result->email; ?></strong></p>
                    <p>Account Status: <strong><?php echo ( $result->status == 1 ) ? "Active" : "Inactive"; ?></strong></p>
                </div>
            </div>
        </div>
    </div>
</div>