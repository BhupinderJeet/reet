<div class="content mt-3">
    <div class="animated fadeIn">
    	<div class="row">
        	<div class="col-md-12">
        		<?php $this->load->view( 'errors/alert' ); ?>
        		
        	</div>
        </div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
				    <div class="card-header">
				        <strong class="card-title"><?php echo $course_name; ?> Topics</strong>
				    </div>
				    <div class="card-body">
						<table id="bootstrap-data-table" class="table table-striped table-bordered">
							<thead>
							  <tr>
							    <th>Topic Name</th>
							    <th>Topic Description</th>
							    <th>Attachment</th>
							    <th>Actions</th>
							  </tr>
							</thead>
							<tbody>
								<?php foreach( $result as $row ): ?>
								<tr>
									<td><?php echo $row->topic_name; ?></td>
									<td><?php echo $row->description; ?></td>
									<td><?php // echo $row->attachment; ?>
										<?php
										if( $row->attachment != "" ) {
											echo anchor( 'topics/download/'.$row->attachment, '<i class="fa fa-download" aria-hidden="true"></i> Download', ['class' => 'badge badge-success', 'title' => 'Download'] );
										}	else 	{
											echo "No File Available.";
										}
										?>
									</td>
									<td>
										<?php
										echo anchor('topics/edit_topic/'.$row->id, ' <i class="fa fa-edit"></i> ', ['class' => 'badge badge-info left-space_a', 'title' => 'Edit']);
										echo anchor('topics/delete/'.$row->id.'/'.$row->course_id, ' <i class="fa fa-trash"></i> ', ['class' => 'badge badge-danger left-space_a', 'title' => 'Delete', 'onclick' => 'return deletecheck();']);
										?>
									</td>
								</tr>
								<?php 
									endforeach;
								?>
							</tbody>
						</table>
			    	</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	function deletecheck() {
		if(confirm('Delete Selected Course?')) {
			return true;
		}	else {
			return false;
		}
	}
</script>
