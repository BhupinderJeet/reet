<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header course_form-title">
                        <strong>Add New Topic</strong>
                    </div>
                    <div class="card-body card-block">
                        <?php
                            $this->load->view( 'errors/alert' );
                            echo form_open_multipart( 'topics/add_topic/'.$data['cr_id'] );
                        ?>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php
                                    echo form_label( 'Topic Name', 'topic_name' );
                                    $tname = [
                                        'type' => 'text',
                                        'name' => 'topic_name',
                                        'placeholder' => 'Topic Name',
                                        'class' => form_error( 'topic_name' ) ? 'input_red form-control' : 'form-control',
                                        'value' => set_value( 'topic_name' )
                                    ];
                                    echo form_input( $tname );
                                    echo form_error('topic_name')
                                ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <?php
                                    echo form_label( 'Description', 'description' );
                                    $desc = [
                                        'name' => 'description',
                                        'placeholder' => 'Description',
                                        'value' => set_value( 'description' )
                                    ];
                                    $attr = [
                                        'class' => form_error( 'description' ) ? 'input_red form-control ckeditor' : 'form-control ckeditor'
                                    ];
                                    echo form_textarea( $desc, '', $attr );
                                    echo form_error('description');
                                ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                               <?php 
                                    echo form_label( 'Add Attachment' ); 
                                       $topic_attachment = [
                                            'type' => 'file',
                                            'id' => 'file-input',
                                            'name' => 'topic_data',
                                            'class' => form_error( 'topic_data' ) ? 'input_red form-control' : 'form-control'
                                        ];
                                        echo form_input($topic_attachment);
                                    echo form_error('topic_data');
                                ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <br />
                            <?php
                                $submit = [
                                    'name' => 'add_topic_submit',
                                    'value' => 'Create',
                                    'class' => 'btn btn-info'
                                ];
                                echo form_submit($submit);
                                echo form_close();
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- .animated -->
</div><!-- .content -->