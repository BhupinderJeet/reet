<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller{ 

	public function __construct($redirectUrl = 'login'){
		parent::__construct();
		
		if(!$this->is_loggedin()){
			$this->redirectIfNotAuth($redirectUrl);
		}
		$this->form_validation->set_error_delimiters('<div class="text-danger form_error">', '</div>');
	}

	public function is_loggedin(){
		return $this->session->has_userdata('auth_user');
	}

	public function redirectIfAuth($url = 'dashboard'){

		if($this->is_loggedin()){
			redirect($url);
		}
	}

	public function redirectIfNotAuth($url = 'login'){

		if(!$this->is_loggedin()){
			redirect($url);
		}
	}

	public function setFlash($type, $message, $icon = 'fa-info-circle'){

		$this->session->set_flashdata(
			'flash', 
			array(
				'type' => $type,
				'message' => $message,
				'icon' => $icon
			)
		);
	}
}