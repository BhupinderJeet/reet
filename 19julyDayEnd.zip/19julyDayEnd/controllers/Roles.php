<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Roles extends MY_Controller {
	function __construct() {
		parent::__construct();
		$this->load->model('Role_model');
	}
	public function add( $id = null ) {
		$this->form_validation->set_rules('role_name', 'Role Name', 'required');
		if( $this->form_validation->run() == TRUE ) {
			$role_name = $this->security->xss_clean( $this->input->post( 'role_name' ) );
			if( $id != null ) {
				$data = [
					'id' => $id,
					'role_name' => $role_name
				];
				$result = $this->Role_model->edit( $data );
			}	else 	{
				$data = [
					'role_name' => $role_name,
					'created' => date('Y-m-d H:i:s')
				];
				$result = $this->Role_model->add( $data );
			}
			
			if( $result ) {
				if( $id != null ) {
					$this->setFlash( 'success', 'Role Updated Successfully.' );
				}	else 	{
					$this->setFlash( 'success', 'Role added Successfully.' );
				}
				redirect('roles/index');
			}	else {
				if( $id != null ) {
					$this->setFlash( 'danger', 'Role could not be updated. Please try again.' );
				}	else 	{
					$this->setFlash( 'danger', 'Role could not be added. Please try again.' );
				}
				redirect('roles/add');
			}
		}
		if( $id != null ){
			$role = $this->Role_model->get_role( $id );
			
			$data = [
				'id' => $id,
				'role_name' => $role->role_name
			];
		}
		$this->load->view('sections/admin_header');
		$this->load->view('roles/add', compact('data'));
		$this->load->view('sections/admin_footer');
	}
	public function index() {
		$result = $this->Role_model->list_roles();
		$this->load->view('sections/admin_header');
		$this->load->view('roles/index', compact('result'));
		$this->load->view('sections/admin_footer');

	}
	public function delete( $id = null ) {
		if( $id != null ) {
			$result = $this->Role_model->delete( $id );
			if( $result ) {
				$this->setFlash( 'success', 'Role deleted Successfully.' );
				redirect('roles/index');
			}	else {
				$this->setFlash( 'danger', 'Role could not be deleted. Please try again.' );
				redirect('roles/index');
			}
		}	else	{
			$this->setFlash( 'danger', 'Invalid Operation' );
			redirect('roles/index');
		}
	}
}