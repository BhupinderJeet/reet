<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Batches extends MY_Controller {
	function __construct() {
		parent::__construct();
		
		$this->load->model( 'Course_model' );
		$this->load->model( 'Batch_model' );
	}
	public function add( $cr_id = null ) {
		if( $cr_id == null ) {
			$this->setFlash( 'danger', 'Add Batch for a course.' );
			redirect('courses/index');
		}
		
		$this->form_validation->set_rules( 'batch_name', 'Batch Name', 'required' );
		$this->form_validation->set_rules( 'start_date', 'Start Date', 'required' );
		$this->form_validation->set_rules( 'end_date', 'End Date', 'required' );
		
		if( $this->form_validation->run() == TRUE ) {
			$batch_name = $this->security->xss_clean( $this->input->post( 'batch_name' ) );
			$start_date = $this->security->xss_clean( $this->input->post( 'start_date' ) );
			$end_date = $this->security->xss_clean( $this->input->post( 'end_date' ) );

			/* here calculate end date */
		// $course = $this->Course_model->get_course( $cr_id );
		$start_date = date('Y-m-d', strtotime($start_date));
		$end_date = date('Y-m-d', strtotime($end_date));
		// $end_date = date('Y-m-d', strtotime( $start_date . '+' . $course->course_duration . ' ' . $course->course_type ));
			
			$data = [
				'course_id' => $cr_id,
				'batch_name' => $batch_name,
				'start_date' => $start_date,
				'end_date' => $end_date,
				'created_by' => $this->session->userdata('auth_user')['id'],
				'created' => date('Y-m-d H:i:s')
			];
			$result = $this->Batch_model->add( $data );
			if( $result ) {
				$this->setFlash( 'success', 'Batch Successfully Added.' );
				redirect( 'batches/index/'.$data['course_id'] );
			}	else {
				$this->setFalsh( 'danger', 'Problem in adding batch. Please Try again.' );
				redirect('batches/add/'.$data['course_id']);
			}
		}
		$data['course_id'] = $cr_id;
		$this->load->view( 'sections/admin_header' );
		$this->load->view('batches/add_batch', compact('data') );
		$this->load->view( 'sections/admin_footer' );
	}
	public function index( $cr_id = null ) {
		if( $cr_id == null ) {
			$this->setFlash( 'danger', 'You Need to select the Course to see batches.' );
			redirect( 'courses/index' );
		}
		$result = $this->Batch_model->list_batches( $cr_id );
		if( !$result ) {
			$this->setFlash( 'danger', 'Batches not added yet for this course.' );
			redirect('batches/add/'.$cr_id);
		}
		$course_name = $this->Course_model->get_course( $cr_id )->course_name;
		$this->load->view( 'sections/admin_header' );
		$this->load->view( 'batches/index', compact('result', 'cr_id', 'course_name') );
		$this->load->view( 'sections/admin_footer' );
	}
	public function delete( $id = null ) {
		if( $id == null ) {
			$this->setFlash( 'danger', 'Invalid Operation.' );
			redirect( 'courses/index' );
		}
		$batch = $this->Batch_model->get_batch( $id );
		$result = $this->Batch_model->delete( $id );
		if( $result && $batch != FALSE ) {
			$this->setFlash( 'success', 'Batch deleted Successfully.' );
			redirect( 'batches/index/'.$batch->course_id );
		}	else {
			$this->setFlash( 'danger', 'Problem in deleting batch. Please try again.' );
			redirect( 'courses/index' );
		}
	}
	public function edit( $id = null ) {
		if( $id == null ) {
			$this->setFlash( 'danger', 'Invalid Operation.' );
			redirect( 'courses/index' );
		}
		
		$this->form_validation->set_rules( 'batch_name', 'Batch Name', 'required' );
		$this->form_validation->set_rules( 'start_date', 'Start Date', 'required' );
		$this->form_validation->set_rules( 'end_date', 'End Date', 'required' );
		if( $this->form_validation->run() == TRUE ) {
			$batch_name = $this->security->xss_clean( $this->input->post( 'batch_name' ) );
			$start_date = $this->security->xss_clean( $this->input->post( 'start_date' ) );
			$end_date = $this->security->xss_clean( $this->input->post( 'end_date' ) );

			$batch = $this->Batch_model->get_batch( $id );
			/* here calculate end date */
			// $course = $this->Course_model->get_course( $batch->course_id );
			$start_date = date('Y-m-d', strtotime($start_date));
			$end_date = date('Y-m-d', strtotime($end_date));
			// $end_date = date('Y-m-d', strtotime( $start_date . '+' . $course->course_duration . ' ' . $course->course_type ));
			
			$data = [
				'id' => $id,
				'course_id' => $batch->course_id,
				'batch_name' => $batch_name,
				'start_date' => $start_date,
				'end_date' => $end_date
			];
			$result = $this->Batch_model->update( $data );
			if( $result ) {
				$this->setFlash( 'success', 'Batch Successfully Updated.' );
				redirect( 'batches/index/'.$data['course_id'] );
			}	else {
				$this->setFlash( 'danger', 'Problem in updating batch. Please Try again.' );
				redirect('batches/edit/'.$id);
			}
		}
		$data['id'] = $id;
		$result = $this->Batch_model->get_batch($id);
		$result->start_date = date('m-d-Y', strtotime( $result->start_date ) );
		$result->end_date = date( 'm-d-Y', strtotime( $result->end_date ) );
		$data['result'] = $result;
		$this->load->view('sections/admin_header');
		$this->load->view('batches/edit', compact('data'));
		$this->load->view('sections/admin_footer');
	}
}