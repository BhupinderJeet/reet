<?php
class Attendance extends MY_Controller {
	function __construct() {
		parent::__construct();
		$this->load->model( 'Course_model' );
		$this->load->model( 'Batch_model' );
		$this->load->model( 'Student_model' );
		$this->load->model( 'Attendance_model' );
	}

	public function add() {
		$this->form_validation->set_rules( 'course', 'Course', 'required' );
		$this->form_validation->set_rules( 'batch', 'Batch', 'required' );
		$this->form_validation->set_rules( 'attendance_date', 'Attendance Date', 'required' );
		if( $this->form_validation->run() == TRUE ) {
			$data= [];
			$at_date = date('Y-m-d', strtotime($this->security->xss_clean( $this->input->post( 'attendance_date' ) )));
			$student_count = $this->security->xss_clean( $this->input->post( 'student_count' ) );
			for( $i = 1; $i <= $student_count; $i++ ) {
				if( $this->input->post( 'attendance_id'.$i ) != null ) {
					//Record already exist. Need to Update It.
					$data = [
						'id' => $this->input->post( 'attendance_id'.$i ),
						'status' => $this->input->post( 'attendance_mark'.$i )
					];

					$result = $this->Attendance_model->update( $data );
				}	else 	{
					//********Add New Record
					$data = [
						'course_id' => $this->security->xss_clean( $this->input->post( 'course' ) ),
						'batch_id' => $this->security->xss_clean( $this->input->post( 'batch' ) ),
						'student_id' => $this->security->xss_clean( $this->input->post( 'student_id'.$i ) ),
						'user_id' => $this->security->xss_clean( $this->input->post( 'user_id'.$i ) ),
						'status' => $this->security->xss_clean( $this->input->post( 'attendance_mark'.$i ) ),
						'attendance_date' => $at_date,
						'created' => date("Y-m-d H:i:s")
					];
					$result = $this->Attendance_model->add_attendance( $data );
				}
			}
			if( $result ) {
				$this->setFlash('success', 'Attendance Submitted Successfuly.');
				redirect('attendance/add');
			}	else 	{
				$this->setFlash('danger', 'Attendance could not be Submitted. Please try again.');
				redirect('attendance/add');
			}
				
		}
		
		$courses = $this->Course_model->list_courses();
		$this->load->view( 'sections/admin_header' );
		$this->load->view( 'attendance/add', compact( 'courses' ) );
		$this->load->view( 'sections/admin_footer' );
		
	}
	public function attendance_students() {
		$attend_date = $this->security->xss_clean( $this->input->post( 'atnd_date' ) );
		if( $this->input->post( 'c_id' ) != "" && $this->input->post( 'b_id' ) != "" && $attend_date != null ) {
			$result = $this->Student_model->get_students_for_attendance( $this->input->post( 'c_id' ), $this->input->post( 'b_id' ), $attend_date );
			if( $result != FALSE ) {
				echo  json_encode( $this->load->view( 'attendance/students_table', compact( 'result' ) ) );
			}	else {
				echo json_encode("No records found.");
			}
		}	else 	{
			echo json_encode("You Need to select course, batch and date to proceed.");
		}
	}
}