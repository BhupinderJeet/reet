<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Courses extends MY_Controller {
	function __construct() {
		parent::__construct();
		
		$this->load->model('Course_model');
	}
	public function index() {
		$result = $this->Course_model->list_courses();
		
		$this->load->view('sections/admin_header');
		$this->load->view('courses/index', compact('result'));
		$this->load->view('sections/admin_footer');
	}
	public function add_course( $id = null ) {
		$this->form_validation->set_rules( 'course_name', 'Course Name', 'required', ['required' => 'You must provide a %s'] );
		$this->form_validation->set_rules( 'course_type', 'Course Type', 'required' );
		$this->form_validation->set_rules( 'course_duration', 'Course Duration', 'required' );
		$this->form_validation->set_rules( 'course_fee', 'Course Fee', 'required' );
		$this->form_validation->set_rules( 'course_description', 'Description', 'required' );
		if( $id == null ) {
			if( $this->form_validation->run() == TRUE ) {

				//fetching form data
				$course_name = $this->security->xss_clean( $this->input->post( 'course_name' ) );
				$course_type = $this->security->xss_clean( $this->input->post( 'course_type' ) );
				$course_duration = $this->security->xss_clean( $this->input->post( 'course_duration' ) );
				$course_fee = $this->security->xss_clean( $this->input->post( 'course_fee' ) );
				$description = $this->security->xss_clean( $this->input->post( 'course_description'));
				$curr_usr = $this->session->userdata('auth_user');

				$data = [
					'course_name' => $course_name,
					'course_type' => $course_type,
					'course_duration' => $course_duration,
					'course_fee' => $course_fee,
					'description' => $description,
					'created_by' => $curr_usr['id'],
					'created' => date("Y-m-d H:i:s")
				];


				$result = $this->Course_model->add_course( $data );
				if( $result ) {
					$this->setFlash( 'success', 'Course added Successfully.' );
					redirect('courses/index');
				}	else  {
					$this->setFlash( 'danger', 'Problem in adding course. Try Again later.' );
				}
			}
			$this->load->view( 'sections/admin_header' );
			$this->load->view( 'courses/add_course' );
			$this->load->view( 'sections/admin_footer' );
		}	else 	{
			if( $this->form_validation->run() == TRUE ) {
				 // fetching form data for edit course.
				$course_name = $this->security->xss_clean( $this->input->post( 'course_name' ) );
				$course_type = $this->security->xss_clean( $this->input->post( 'course_type' ) );
				$course_duration = $this->security->xss_clean( $this->input->post( 'course_duration' ) );
				$course_fee = $this->security->xss_clean( $this->input->post( 'course_fee' ) );
				$description = $this->security->xss_clean( $this->input->post( 'course_description' ) );
				$data = [
					'id' => $id,
					'course_name' => $course_name,
					'course_type'=> $course_type,
					'course_duration'=> $course_duration,
					'course_fee' => $course_fee,
					'description' => $description
				];
				$result = $this->Course_model->edit( $data );
				if( $result ) {
					$this->setFlash( 'success', 'Course Updated Successfully.' );
				}	else  {
					$this->setFlash( 'danger', 'Problem in updating Course. Please Try Again' );
				}
			}

			$data = [];
			$this->load->database();
			$this->db->where( 'id', $id );
			$course = $this->db->get( 'courses' );
			if( $course === FALSE ) {
				redirect('courses/index');
			}
			$data['course'] = $course->row();
			$this->load->view('sections/admin_header');
			$this->load->view('courses/add_course', $data );
			$this->load->view('sections/admin_footer');
		}
		
	}
	public function delete( $id = null ) {
		$result = $this->Course_model->delete( $id );
		if( $result == True ) {
			$this->setFlash( 'success', 'Course Deleted Successfully.' );
			redirect( 'courses/index' );
		}	else 	{
			$this->setFlash( 'danger', 'Problem in deleting Course. Please Try Again' );
			redirect( 'courses/index' );
		}
	}
}