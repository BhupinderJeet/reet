<?php
class Medias extends MY_Controller {
	function __construct() {
		parent::__construct();
		$this->load->model('Media_model');
		$this->load->view('sections/admin_header');
	}
	public function index() {
		$videos = $this->Media_model->get_all();
		if( $videos != FALSE ) {
			$this->load->view( 'medias/view_all', compact( 'videos' ) );
			$this->load->view( 'sections/admin_footer' );
		}
	}
	public function add() {
		$this->form_validation->set_rules( 'add_link', 'Add Link', 'required' );
		if( $this->form_validation->run() == TRUE ) {
			$link = $this->security->xss_clean( $this->input->post( 'add_link' ) );

			$data = [
				'link' => $link,
				'user_id' => $this->session->userdata('auth_user')['id'],
				'created' => date( 'Y-m-d H:i:s' )
			];
			$result = $this->Media_model->add( $data );
			if( $result ) {
				$this->setFlash('success', 'Video link added successfully.');
				redirect('medias/add');
			}	else 	{
				$this->setFlash('danger', 'Error while saving your link. Please try again.');
				redirect('medias/add');
			}
		}
		$this->load->view( 'medias/add_link' );
		$this->load->view( 'sections/admin_footer' );
	}
	public function my_videos() {
		if( $this->session->userdata( 'auth_user' ) != null ) {
			$videos = $this->Media_model->get_my_links( $this->session->userdata('auth_user' )['id'] );
			if( $videos != FALSE ) {
				$this->load->view( 'medias/my_videos', compact('videos') );
				$this->load->view( 'sections/admin_footer' );
			}
		}
	}
}