<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends MY_Controller {
	function __construct() {

		parent::__construct();
		
		$this->load->model( 'User_model' );
		$this->load->model( 'Role_model' );
		$this->load->library('encryption');
		$this->load->view( 'sections/admin_header' );
	}
	public function logout() {
		$this->session->unset_userdata('auth_user');
		$this->setFlash( 'success', 'Successfully Logout.' );
		redirect('login');
	}
	public function add() {
		$this->form_validation->set_rules( 'username', 'Username', 'required|is_unique[users.email]|valid_email', ['is_unique' => 'The %s already exist. Please use another one.'] );
		$this->form_validation->set_rules( 'password', 'Password', 'required' );
		$this->form_validation->set_rules( 'role', 'Role', 'required|callback_role_check' );
		if( $this->form_validation->run() == TRUE ) {
			$username = $this->security->xss_clean( $this->input->post( 'username' ) );
			$password = $this->security->xss_clean( $this->input->post( 'password' ) );
			$role = $this->security->xss_clean( $this->input->post( 'role' ) );
			$enc_password = password_hash($password, PASSWORD_DEFAULT);
			// echo $enc_password;
			$data = [
				'email' => $username,
				'password' => $enc_password,
				'role' => $role,
				'created' => date('Y-m-d H:i:s')
			];
			$result = $this->User_model->add( $data );
			if( $result ) {
				$this->setFlash( 'success', 'User added Successfully.' );
				redirect('users/index');
			}	else {
				$this->setFlash( 'danger', 'User Could not be added.' );
				redirect('users/add');
			}
		}
		
		$data = [
			'roles' => $this->Role_model->list_roles(),
		];
		// $this->load->view( 'sections/admin_header' );
		$this->load->view( 'users/add', compact( 'data' ) );
		$this->load->view( 'sections/admin_footer' );
	}
	public function index() {
		$result = $this->User_model->list_users();
		if( $result != FALSE ) {
			$this->load->view( 'users/userlist', compact('result') );
			$this->load->view( 'sections/admin_footer' );

		}
	}
	public function role_check( $role = null ) {
		if( $role != null ) {
			$result = $this->Role_model->role_exist( $role );
			if( $result ) {
				return TRUE;
			}
		}
		$this->form_validation->set_message('role_check', 'The {field} field is Invalid.');
		return FALSE;
	}
	public function delete( $id = null ) {
		if( $id != null ) {
			$result = $this->User_model->delete( $id );
			if( $result ) {
				$this->setFlash( 'success', 'User Deleted Successfully.' );
				redirect('users/index');
			}	else 	{
				$this->setFlash( 'danger', 'User could not be Deleted. Please Try again.' );
				redirect('users/index');
			}
		}
	}
	public function my_profile() {
        if( $this->session->userdata( 'auth_user') != null ) {
        	if( $this->session->userdata( 'auth_user' )[ 'role' ] == 2 ) {
        		$result = $this->User_model->get_user_details( $this->session->userdata('auth_user')['id'] );
        		if( $result != FALSE ) {
	            	$this->load->view('users/admin_profile', compact('result'));
	            	$this->load->view('sections/admin_footer');
	            }
	        }	else 	{
	        	$result = $this->User_model->my_profile( $this->session->userdata('auth_user')['id'] );
	        	if( $result != FALSE ) {
	            	$this->load->view('users/my_profile', compact('result'));
	            	$this->load->view('sections/admin_footer');
	            }
	        }
            
            
        }	else 	{
        	$this->setFlash('danger', 'You need to login to change your password');
        	redirect( 'login' );
        }
    }
    public function change_password() {
    	$this->form_validation->set_rules('old_password', 'Old Password', 'required');
		$this->form_validation->set_rules('new_password', 'New Password', 'required');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|required|matches[new_password]');
		//***************
		if( $this->input->post('change_pass_submit') != null ) {
			$form_data = [
				'old_password' => $this->input->post('old_password'),
				'new_password' => $this->input->post('new_password'),
				'confirm_password' => $this->input->post('confirm_password')
			];
		}	else 	{
			$form_data = "";
		}
		//**************
		$result = $this->User_model->get_user_details( $this->session->userdata( 'auth_user' )['id'] );
		if( $result != FALSE ) {
			//*******************change password code***************
			if( $this->form_validation->run() == TRUE ) {
				$old_password = $this->input->post('old_password');
				$new_password = $this->input->post('new_password');
				$confirm_password = $this->input->post('confirm_password');
							
				// check if old password is correct.
				
				if( !password_verify( $old_password, $result->password ) ) {
					$this->session->setFlash( 'danger', 'Old Password is Incorrect' );
					redirect( 'users/change_password' );
				}
				
				// correct old password then proceed here
				$new_data = [
					'id' => $this->session->userdata('auth_user')['id'],
					'password' => password_hash( $new_password, PASSWORD_DEFAULT)
				];
				if( $this->User_model->update( $new_data ) ) {
					$this->setFlash( 'success', 'Password Changes Successfully.' );
					redirect( 'users/my_profile' );
				}	else 	{
					$this->session->setFlash( 'danger', 'Password could not be Changed. Please try again.' );
					redirect( 'users/change_password' );
				}

			}
			$data = [
				'form_data' => $form_data
			];
			//*************************************
			// $this->load->view( 'sections/admin_header' );
			$this->load->view( 'users/change_my_password', compact('data') );
			$this->load->view( 'sections/admin_footer'  );
		}
    }
	
}