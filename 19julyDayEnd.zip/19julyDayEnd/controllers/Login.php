<?php
class Login extends CI_Controller {
	function __construct() {
		parent::__construct();

		$this->load->model( 'User_model' );
		$this->load->model( 'Role_model' );
		$this->load->library('encryption');
	}
	public function index($msg = null) {
		if( $this->session->userdata( 'auth_user' ) == "" ) {
			$this->form_validation->set_rules('username', 'Username', 'trim|required|valid_email');
			$this->form_validation->set_rules('password', 'Password', 'required', ['required' => 'You must provide a %s . ']);
			
			if( $this->form_validation->run() == TRUE ) {
				
				$result = $this->User_model->validate();
				if( $result != FALSE ) {
					if( $result->status == 1 ) {
						$data = array(
		                    'id' => $result->id,
		                    'email' => $result->email,
		                    'role' => $result->role,
		                    'validated' => true
		                );
		            	$this->session->set_userdata('auth_user',$data);

						redirect('dashboard');
					}	else 	{
						$this->session->set_flashdata('error', 'Your account is not verified. Please check your email to verify account.');
						redirect( 'login' );
					}
				}	else	{
					$this->session->set_flashdata( 'error', 'Username / Password Incorrect.' );
					redirect('login');
				}
				// $this->load->view('pages/successpage');
			}

			$this->load->view('login-header');
			$this->load->view('pages/login');
			$this->load->view('login_footer');
		}	else 	{
			redirect('dashboard/index');
		}
			
	}
	
	public function verify_account( $cypher_email = null ) {
		if( $cypher_email != null ) {

			$this->form_validation->set_rules('old_password', 'Old Password', 'required');
			$this->form_validation->set_rules('new_password', 'New Password', 'required');
			$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|required|matches[new_password]');
			//***************
			if( $this->input->post('change_pass_submit') != null ) {
				$form_data = [
					'old_password' => $this->input->post('old_password'),
					'new_password' => $this->input->post('new_password'),
					'confirm_password' => $this->input->post('confirm_password')
				];
			}
			//**************
			$result = $this->User_model->get_by_token( $cypher_email );
			if( $result != FALSE ) {
				if( $result->status == 1 ) {
					$this->session->set_flashdata( 'success', 'Account Aready Verified...' );
					redirect('login');
				}

				//*******************change password code***************
				if( $this->form_validation->run() == TRUE ) {
					$old_password = $this->input->post('old_password');
					$new_password = $this->input->post('new_password');
					$confirm_password = $this->input->post('confirm_password');
								
					// check if old password is correct.
					
					if( !password_verify( $old_password, $result->password ) ) {
						$this->session->set_flashdata( 'error', 'Old Password is Incorrect' );
						redirect( 'login/verify_account/'.$cypher_email );
					}
					
					// correct old password then proceed here
					$new_data = [
						'token' => $cypher_email,
						'password' => password_hash( $new_password, PASSWORD_DEFAULT),
						'status' => 1
					];
					if( $this->User_model->update_by_token( $new_data ) ) {
						$this->set_flashdata( 'success', 'Password Changes Successfully. and account has been activated.' );
						redirect( 'login' );
					}	else 	{
						$this->session->set_flashdata( 'error', 'Password could not be Changed. Please try again.' );
						redirect( 'login/verify_account/'.$cypher_email );
					}

				}

				//*************************************
				$data = [
					'token' => $cypher_email,
					'form_data' => isset( $form_data ) ? $form_data : ""
				];
				$this->load->view('sections/admin_header');
				$this->load->view('users/change_password', compact('data'));
				$this->load->view('sections/admin_footer');
			}	else 	{
				print_r( $result );
			}
		}	else 	{
			$this->session->set_flashdata( 'error', 'You are not allowed to access it.' );
			redirect('login');
		}
	}
}