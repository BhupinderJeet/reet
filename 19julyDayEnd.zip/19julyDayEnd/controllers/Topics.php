<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Topics extends MY_Controller {
	function __construct() {
		parent::__construct();
		$this->load->model('Topic_model');
		$this->load->model('Course_model');
	}
	public function add_topic( $cr_id = null ) {
		if( $cr_id != null ) {
			$this->form_validation->set_rules( 'topic_name', 'Topic Name', 'required' );
			$this->form_validation->set_rules( 'description', 'Description', 'required' );
			if( $this->form_validation->run() == TRUE ) {
				$topic_name = $this->security->xss_clean($this->input->post('topic_name'));
				$description = $this->security->xss_clean( $this->input->post('description'));

				if( $_FILES['topic_data']['name'] != "" ) {
					$attachment = $this->upload_file($_FILES['topic_data']);
					if( isset( $attachment['error'] ) ) {
						$this->setFlash( 'danger', "Error In uploading File. Please Try Again.");
						redirect( 'topics/add_topic/'.$cr_id );
					}	else 	{
						$attachment_name = $attachment['file_name'];
					}
				}	else 	{
					$attachment_name = "";
				}
				$data = [
					'topic_name' => $topic_name,
					'course_id' => $cr_id,
					'description' => $description,
					'attachment' => $attachment_name,
					'created_by' => $this->session->userdata('auth_user')['id'],
					'created' => date("Y-m-d H:i:s")
				];
				$result = $this->Topic_model->add_topic( $data );
				if( $result ) {
					$this->setFlash( 'success', 'Topic added Successfully.' );
					redirect( 'topics/course_topics/'.$cr_id );
				}	else  {
					$this->setFlash( 'danger', 'Problem in adding topic. Try Again later.' );
					redirect( 'topics/add_topic/'.$cr_id );
				}
				
				
			}
			$data['cr_id'] = $cr_id;
			$this->load->view( 'sections/admin_header' );
			$this->load->view( 'topics/add', compact('data') );
			$this->load->view( 'sections/admin_footer' );
		}	else 	{
			$this->setFlash( 'danger', 'You need to add Topic under a course.' );
			redirect('courses/index');
		}
	}
	public function upload_file( $filedata = '' ) {
		if(!empty($filedata)){
			// print_r($filedata);die;
			$config['upload_path'] = './assets/uploads/';
			$config['allowed_types'] = 'gif|jpg|png|pdf|doc';
			$config['max_size'] = 100;

			$this->load->library('upload', $config);
			if( !$this->upload->do_upload( 'topic_data' ) ) {
				return ['error' => $this->upload->display_errors()];
			}else {
				return  $this->upload->data();
			}
		}
		return FALSE;
	}
	public function course_topics( $cr_id = null ) {
		if( $cr_id != null ) {
			$result = $this->Topic_model->list_course_topics( $cr_id );
			if( $result == FALSE ) {
				$this->setFlash( 'danger', 'No record available. You need to add a topic in this Course.' );
				redirect( 'topics/add_topic/'.$cr_id );
			}
			$course_name = $this->Course_model->get_course($cr_id)->course_name;
			$this->load->view( 'sections/admin_header' );
			$this->load->view( 'topics/course_topics', compact( 'result', 'course_name' ) );
			$this->load->view( 'sections/admin_footer' );

		} 
	}
	public function download( $f_name ) {
		$this->load->helper('download');
		$path = base_url() . "assets/uploads/" . $f_name;
		$path = file_get_contents( $path );
		force_download( $f_name, $path );

	}
	public function delete( $t_id = null, $cr_id = null ) {
		if( $t_id != null ) {
			$result = $this->Topic_model->delete( $t_id );
			if( $result != FALSE ) {
				$this->setFlash( 'success', 'Topic Deleted Successfully.' );
				redirect( 'topics/course_topics/'.$cr_id );
			}
		}
	}
	public function edit_topic( $id = null ) {
		if( $id != null ) {
			$this->form_validation->set_rules( 'topic_name', 'Topic Name', 'required' );
			$this->form_validation->set_rules( 'description', 'Description', 'required' );

			$this->load->database();
			$this->db->where( 'id', $id );
			$topic = $this->db->get( 'topics' )->row();
			if ( $topic == null ) {
				redirect('courses/index');
			}


			if( $this->form_validation->run() == TRUE ) {
				$topic_name = $this->security->xss_clean($this->input->post('topic_name'));
				$description = $this->security->xss_clean( $this->input->post('description'));
				//*********************
				if($_FILES['topic_data']['name'] != ""){
					$attachment = $this->upload_file( $_FILES['topic_data'] );
					if( isset( $attachment['error'] ) ) {
						$this->setFlash( 'danger', "Error In uploading File. Please Try Again.");
						redirect( 'topics/edit_topic/'.$id );
					}	else  {
						$attachment_name = $attachment['file_name'];
					}
				}	else {
						$attachment_name = $this->security->xss_clean( $this->input->post( 'hide_file_name' ) );
				}

				//*****************
				
				$data = [
					'id' => $id,
					'topic_name' => $topic_name,
					'description' => $description,
					'attachment' => $attachment_name
				];
						
					
				$result = $this->Topic_model->edit( $data );
								
				if( $result ) {
					$this->setFlash( 'success', 'Topic updated Successfully.' );
					redirect( 'topics/course_topics/'.$topic->course_id );
				}	else  {
					$this->setFlash( 'danger', 'Problem in updating topic. Try Again later.' );
					redirect( 'topics/edit_topic/'.$data );
				}
			}
			
			$this->load->view( 'sections/admin_header' );
			$this->load->view( 'topics/edit', compact('topic') );
			$this->load->view( 'sections/admin_footer' );
		}	else 	{
			$this->setFlash( 'danger', 'You need to edit Topic under a course.' );
			redirect('courses/index');
		}
	}
}