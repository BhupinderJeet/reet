<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Students extends MY_Controller {
	function __construct() {
		parent::__construct();

		$this->load->model('User_model');
		$this->load->model('Student_model');
		$this->load->model('Course_model');
		$this->load->model('Batch_model');
		$this->load->model('Role_model');
	}
	public function index() {
		$result = $this->Student_model->get_all_students();
		if( $result != FALSE ) {
			$data = [];
			$course_name = [];
			$batch_name = [];
			foreach( $result as $row ) {
				// print_r($row->course_id . " " . $row->batch_id);
				$row = (array)$row;
				$row['course_name'] = $this->Course_model->get_course( $row['course_id'] )->course_name;
				$row['batch_name'] = $this->Batch_model->get_batch( $row['batch_id'] )->batch_name;
				$row = (object)$row;
				array_push( $data, $row );
			}

			$this->load->view('sections/admin_header');
			$this->load->view( 'students/index', compact('data'));
			$this->load->view('sections/admin_footer');
		}

	}
	public function add( $id = null ) { 
		$this->form_validation->set_rules( 'student_name', 'Student Name', 'required' );
		$this->form_validation->set_rules( 'student_email', 'Student Email', 'required' );
		$this->form_validation->set_rules( 'contact_number', 'Contact Number', 'required' );
		$this->form_validation->set_rules( 'parents_name', 'Parents Name', 'required' );
		$this->form_validation->set_rules( 'parents_contact', 'Parents Contact Number', 'required' );
		$this->form_validation->set_rules( 'permanent_address', 'Permanent Address', 'required' );
		$this->form_validation->set_rules( 'local_address', 'Correspondence Address', 'required' );
		$this->form_validation->set_rules( 'qualification', 'Qualification', 'required' );
		$this->form_validation->set_rules( 'course', 'Course', 'required' );
		$this->form_validation->set_rules( 'batch', 'Batch', 'required' );
		$this->form_validation->set_rules( 'admission_date', 'Admission Date', 'required' );

		if( $this->form_validation->run() == TRUE ) {
			$student_name = $this->security->xss_clean( $this->input->post( 'student_name' ) );
			$student_email = $this->security->xss_clean( $this->input->post( 'student_email' ) );
			$contact_number = $this->security->xss_clean( $this->input->post( 'contact_number' ) );
			$alternate_contact = $this->security->xss_clean( $this->input->post( 'alternate_contact' ) );
			$parents_name = $this->security->xss_clean( $this->input->post( 'parents_name' ) );
			$parents_contact = $this->security->xss_clean( $this->input->post( 'parents_contact' ) );
			$permanent_address = $this->security->xss_clean( $this->input->post( 'permanent_address' ) );
			$local_address = $this->security->xss_clean( $this->input->post( 'local_address' ) );
			$qualification = $this->security->xss_clean( $this->input->post( 'qualification' ) );
			$course = $this->security->xss_clean( $this->input->post( 'course' ) );
			$batch = $this->security->xss_clean( $this->input->post( 'batch' ) );
			$admission_date = $this->security->xss_clean( $this->input->post( 'admission_date' ) );
			$admission_date = date( 'y-m-d', strtotime( $admission_date ) );
			$role = $this->security->xss_clean($this->input->post( 'role' ) );

			$sb = $this->security->xss_clean( $this->input->post( 'hide_pic_name' ) );


			// ***********check if email already registered to keep it unique
			if( $this->User_model->username_exist($student_email) != FALSE ) {
				$this->setFlash( 'danger', "The Email id already Registered. Please try with another one.");
				redirect('students/add');
			}

			//*************check if image is uploaded or not as it's not a required field
			if($_FILES['profile_pic']['name'] != ""){
				$profile_pic = $this->upload_pic( $_FILES['profile_pic'] );
				if( isset( $profile_pic['error'] ) ) {

					$this->setFlash( 'danger', "Error In uploading Image. Please Try Again.");
					redirect('students/add');
					
				}	else  {
					$pic_name = $profile_pic['file_name'];
				}
				
			}	else {
				if( $id != null ) {
					$pic_name = $this->security->xss_clean( $this->input->post( 'hide_pic_name' ) );
				}	else 	{
					$pic_name = "";
				}
			}


			if( $id != null ) {
				// **********for student edit
				$data = [
					'id' => $id,
					'name' => $student_name,
					'primary_contact' => $contact_number,
					'alternate_contact' => $alternate_contact,
					'parent_name' => $parents_name,
					'parent_contact' => $parents_contact,
					'permanent_address' => $permanent_address,
					'local_address' => $local_address,
					'qualification' => $qualification,
					'course_id' => $course,
					'batch_id' => $batch,
					'admission_date' => $admission_date,
					'profile_pic' => $pic_name
				];
			}	else {
				// ***********************for student add.

				// ************** code to generate password starts *********
				$alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890@~*(_)';
			    $password = array(); 
			    $alpha_length = strlen($alphabet) - 1; 
			    for ($i = 0; $i < 8; $i++) 
			    {
			        $n = rand(0, $alpha_length);
			        $password[] = $alphabet[$n];
			    }
			    $pass = password_hash(implode($password), PASSWORD_DEFAULT); 

			    // *************password generation code ends **********************
			    $token = md5( $student_email.time() );
			    //print_r($token);die;
			    // array for user table
		    	$data_user = [
					'email' => $student_email,
					'password' => $pass,
					'role' => 7,
					'token' =>$token,
					'token_created' => date('Y-m-d H:i:s'),
					'created_by' => $this->session->userdata('auth_user')['id'],
					'created' => date('Y-m-d H:i:s')
				];
				$result_user = $this->User_model->add( $data_user );
				if( !$result_user ) {
				
					$this->setFlash( 'danger', "Student could not be created. Please try again.");
					redirect( 'students/add' );
				}
				
				$user_id = $this->User_model->username_exist($student_email);
				// array for students table
				$data = [
					'name' => $student_name,
					'primary_contact' => $contact_number,
					'alternate_contact' => $alternate_contact,
					'parent_name' => $parents_name,
					'parent_contact' => $parents_contact,
					'permanent_address' => $permanent_address,
					'local_address' => $local_address,
					'qualification' => $qualification,
					'course_id' => $course,
					'batch_id' => $batch,
					'admission_date' => $admission_date,
					'profile_pic' => $pic_name,
					'user_id' => $user_id,
					'created' => date('Y-d-m h:i:s')
				];
			}
				
			if( $id != null ) {
				$result = $this->Student_model->update( $data );
			}	else  {
				$result = $this->Student_model->add( $data );

				if( $result ) {
					//************sending Email to students to set their freelancer account
					$this->email->from( 'r4nifty@gmail.com', 'Academics Admin' );
					$this->email->to( $student_email );
					$this->email->subject('Academics Website. Freelancer acoount.');

					$msg = "http://avantgardedigital.com/admin_panel/login/verify_account/".$token;
					$msg .= "  Click on above link to confirm your account. and set your password. ";
					$msg .= "  Your Current Username: ".$student_email."  ";
					$msg .= "  Your current password: ".implode($password)."  ";
					$msg .= "  Thank You for being a part of us.";

					$this->email->message($msg);

					if( !$this->email->send() ) {
						$this->setFlash( 'danger', "Email could not be sent. Email Id is registered.");
						redirect('students/add');
					}
				}
			}
			
			if( $result ) {
				if( $id != null ) {
					$msg = "Student Information updated successfully.";
				}	else  {
					$msg = "Student added successfully";
				}
				$this->setFlash( 'success', $msg );
				redirect('students/index');
			}	else {
				if( $id != null ){
					$msg = "Student Information couldn't be updated. Please try again.";
				}	else  	{
					$msg = "Student couldn't added. Please try again.";
				}
				
				$this->setFlash( 'dander', $msg );
				redirect('students/add');
			}
		}
		if( $id != null ) {
			$data['result'] = $this->Student_model->get_student_details( $id );
		}
		$data['roles'] = $this->Role_model->list_roles();
		$data['courses'] = $this->Course_model->list_courses();
		$this->load->view('sections/admin_header');
		$this->load->view('students/add', compact('data'));
		$this->load->view('sections/admin_footer');
	}

	public function upload_pic( $filedata = '' ) {
		if(!empty($filedata)){
			// print_r($filedata);die;
			$config['upload_path'] = './assets/images/students/';
			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size'] = 100;

			$this->load->library('upload', $config);
			if( !$this->upload->do_upload( 'profile_pic' ) ) {
				return ['error' => $this->upload->display_errors()];
			}else {
				return  $this->upload->data();
			}
		}
		return FALSE;
	}
	public function get_batches( ) {
		
		$result = $this->Batch_model->course_batches( $this->input->post('id' ));
		
		echo json_encode(array(
			'status' => $result?'success':'danger',
			'data' => $result
		));

	}
	public function delete( $id = null ) {
		$result = $this->Student_model->delete( $id );
		if( $result ) {
			$this->setFlash( 'success', 'Student Record Deleted Successfully.' );
			redirect('students/index');
		}	else {	
			$this->setFlash( 'danger', 'Student Record could not be Deleted. Please Try Again.' );
			redirect('students/index');
		}
	}
	public function student_details( $id = null ) {
		if( $id != null ) {
			$result = $this->Student_model->get_student_details( $id );
			if( $result != FALSE ) {
				$this->load->view( 'sections/admin_header' );
				$this->load->view( 'students/student_details', compact('result'));
				$this->load->view( 'sections/admin_footer' );
			} 
		}
	}
}