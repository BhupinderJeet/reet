<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Freelancers extends MY_Controller {
	function __construct() {
		parent::__construct();
		$this->load->model('Student_model');
		$this->load->model('User_model');
		$this->load->view( 'sections/admin_header' );
	}
	public function add() {
		if( $this->input->post( 'add_freelancer_submit' ) != null ) {
			if( !empty( $this->input->post( 'student_list') ) ) {
				$st_count = count( $this->input->post( 'student_list' ) );
				$error_list = [];
			    $success_list = [];

				foreach( $this->input->post( 'student_list' ) as $student ) {

					$student_detail = $this->Student_model->get_student_details( $student );
					
			    	$data = [
			    		'id' => $student_detail->user_id,
						'role' => 3
					];
					$res = $this->User_model->update( $data );

					if( !$res ) {
						array_push( $error_list, $student_detail->user_id );
					}	else 	{
						array_push($success_list, $student_detail->user_id);
					}
				}
				if( count( $success_list ) > 0 ) {
					$this->setFlash( 'success', 'Students are successfully turned to Freelancers.');
				}
				if( count( $error_list ) > 0 )  {
					$this->setFlash( 'danger', count($error_list) . ' number of students could not be turned to Freelancers. Please try again.');
				}
				redirect('freelancers/add');

			}	else {
				$this->setFlash( 'danger', 'You need to select atleast one Student to make it a freelancer.' );
				redirect('freelancers/add');
			}
		}
		$students = $this->Student_model->get_students_only();
		if( $students != FALSE ) {
			
			$this->load->view( 'freelancers/add_freelancer', compact('students') );
			$this->load->view( 'sections/admin_footer' );
		}	else	{
			$this->setFlash( 'danger', 'No students Found in the list.' );
			redirect('students/index');
		}
	}
	public function dashboard() {
		if( $this->session->userdata( 'auth_user' ) != null ) {
			$result = $this->User_model->freelancer_dashboard_data();
			if( $result != FALSE ) {
				$this->load->view( 'dashboard/freelancer_dashboard', compact('result') );
				$this->load->view( 'sections/admin_footer' );
			}
		}
	}
}