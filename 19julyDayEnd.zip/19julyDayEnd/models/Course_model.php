<?php
class Course_model extends CI_Model {
	function __construct() {
		parent::__construct();
		$this->load->library('session');
	}

	public function add_course( $data = [] ) {
		if( $data != [] ) {
			$query = $this->db->insert('courses', $data);
			if( $query ) {
				return TRUE;
			}
		}
		return FALSE;
	}
	public function list_courses() {
		$query = $this->db->get( 'courses' );
		// print_r($query);die;
		if( $query->num_rows() > 0 ) {
			$result = $query->result();
			return $result;
		}	else 	{
			return FALSE;
		}
	}
	public function edit( $data = [] ) {
		if( $data != [] ) {
			$this->db->where('id', $data['id']);
			$query = $this->db->update( 'courses', $data );
			if( $query ) {
				return TRUE;
			}
		}
		return FALSE;
	}
	public function delete( $id = null ) {
		$this->db->where( 'id', $id );
		$result = $this->db->delete('courses');
		if( $result ) {
			return TRUE;
		}	
		return FALSE;
	}
	public function get_course( $id = null ) {
		if( $id == null) {
			return FALSE;
		}
		$this->db->where( 'id', $id );
		$res = $this->db->get( 'courses' );
		if( $res->num_rows() > 0 ) {
			return $res->row();
		}
		return FALSE;
	}
}