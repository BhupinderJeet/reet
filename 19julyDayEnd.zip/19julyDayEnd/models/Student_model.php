<?php
class Student_model extends CI_Model {
	function __construct() {
		parent::__construct();
	}
	public function add( $data = [] ) {
		if( isset( $data ) ) {
			$result = $this->db->insert( 'students', $data );
			if( $result ) {
				return TRUE;
			}
		}
		return FALSE;
	}
	public function get_all_students() {
		$result = $this->db->get( 'students' );
		if( $result->num_rows() > 0 ) {
			return $result->result();
		}
		return FALSE;
	}
	public function delete( $id = null ) {
		if( $id != null ) {
			$this->db->where( 'id', $id );
			$res = $this->db->delete( 'students' );
			if( $res ) {
				return TRUE;
			}
		}
		return FALSE;
	}
	public function get_student_details( $id = null ) {
		if( $id != null ) {
			$this->db->select('s.*, c.course_name, b.batch_name')
			->from('students s')
			->join('courses c', 's.course_id = c.id', 'left')
			->join('batches b', 's.batch_id = b.id', 'left')
			->where('s.id', $id);
			
			$res = $this->db->get();
			if( $res->num_rows() > 0 ) {
				$result = $res->row();
				return $result;
			}
		}
		return FALSE;
	}
	public function update( $data = [] ) {
		if( isset( $data ) ) {
			$this->db->where( 'id', $data['id'] );
			$res = $this->db->update('students', $data);
			if( $res ) {
				return TRUE;
			}	else 	{
				return FALSE;
			}
		}
	}
	public function get_students_only() {
		$this->db->select('u.*, s.*, c.course_name, b.batch_name')
		->from( 'users u' )
		->join( 'students s', 'u.id = s.user_id', 'left' )
		->join( 'courses c', 's.course_id = c.id', 'left' )
		->join( 'batches b', 's.batch_id = b.id', 'left' )
		->where( 'role', 7);
		$students = $this->db->get();
		
		if( $students->num_rows() > 0 ) {
			return $students->result();
		}
		return FALSE;
	}
	public function get_students_for_attendance( $course_id = null, $batch_id = null , $attendance_date = null) {
		if( $course_id != null && $batch_id != null ) {
			$query = "select s.*, u.email, att.id as att_id, att.attendance_date, att.status from students as s LEFT JOIN users as u ON s.user_id = u.id LEFT JOIN attendance as att ON att.course_id = ".$course_id." and att.batch_id=".$batch_id." and att.student_id = s.id and DATE(att.attendance_date) = '".date("Y-m-d", strtotime($attendance_date))."' where  s.course_id = ".$course_id." and s.batch_id = ".$batch_id;
			$students = $this->db->query($query);
			if( $students->num_rows() > 0 ) {
				return $students->result();
			}
		}
		return FALSE;
	}
}