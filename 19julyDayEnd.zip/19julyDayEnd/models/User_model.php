<?php
class User_model extends CI_Model {
	function __construct() {
		parent::__construct();
        $this->load->library('session');
	}
	public function validate(){
        // grab user input
        $username = $this->security->xss_clean($this->input->post('username'));
        $password = $this->security->xss_clean($this->input->post('password'));

        // Prep the query
        $this->db->where('email', $username);
        // $this->db->where('password', $password);
        
        // Run the query
        $query = $this->db->get('users');

        // Let's check if there are any results
        if($query->num_rows() == 1)
        {
            if( password_verify( $password ,$query->row()->password ) ) {
                return $query->row();
            }
        }
        // If the previous process did not validate
        // then return false.
        return false;
    }

    public function add ( $data = [] ) {
        if( $data != [] ) {
             $result = $this->db->insert( 'users', $data );
            if( $result ) {
                return TRUE;
            }
        }
        return FALSE;
    }
    public function list_users() {
        $this->db->select('u.*,r.role_name')
             ->from('users u')
             ->join('roles r','u.role = r.id','left')
             ->where('u.id <>',38 );
        $users = $this->db->get();
        
        if( $users->num_rows() > 0 ) {
            return $users->result();
        }
        return FALSE;
    }
    public function username_exist( $un = null ) {
        if( $un != null ) {
            $this->db->where( 'email', $un );
            $result = $this->db->get('users');
            if($result->num_rows() > 0) {
                return $result->row()->id;
            }
        }
        return FALSE;
    }
    public function delete( $id = null ) {
        if( $id != null ) {
            $this->db->where( 'id', $id );
            $result = $this->db->delete('users');
            if( $result ) {
                return TRUE;
            }
        }
        return FALSE;
    }

    public function get_user_details( $id = null ) {
        if( $id != null ) {
            $this->db->where( 'id', $id );
            $result = $this->db->get( 'users' );
            if( $result->num_rows() == 1 ) {
                return $result->row();
            }
        }
        return FALSE;
    }

    public function update( $data = [] ) {
        if( $data != [] ) {
            $this->db->where( 'id', $data['id'] );
            $res = $this->db->update( 'users', $data );
            if( $res ) {
                return TRUE;
            }
        }
        return FALSE;
    }
    public function update_by_token( $data = [] ) {
        if( $data != [] ) {
            $this->db->where( 'token', $data['token'] );
            $res = $this->db->update( 'users', $data );
            if( $res ) {
                return TRUE;
            }
        }
        return FALSE;
    }
    public function get_by_token( $token = null ) {
        if( $token != null ) {
            $this->db->where( 'token', $token );
            $result = $this->db->get('users');
            if( $result->num_rows() == 1 ) {
                return $result->row();
            }
        }
        return FALSE;
    }

    public function my_profile( $id = null ) {
        if( $id != null ) {
            $this->db->select('u.*, s.*, c.course_name, b.batch_name')
            ->from( 'users u' )
            ->join( 'students s', 'u.id = s.user_id' )
            ->join( 'courses c', 's.course_id = c.id' )
            ->join( 'batches b', 's.batch_id = b.id' )
            ->where( 'u.id', $id );
            $details = $this->db->get();
            if( $details->num_rows() == 1 ) {
                return $details->row();
            }
        }
        return FALSE;
    }
    public function freelancer_dashboard_data() {
        $this->db->select( 'u.email, u.status, s.name, s.profile_pic, c.course_name, b.batch_name, r.role_name, count(m.id) as my_videos_count' )
        ->from( 'users u' )
        ->join( 'students s', 'u.id = s.user_id' )
        ->join( 'courses c', 's.course_id = c.id' )
        ->join( 'batches b', 's.batch_id = b.id' )
        ->join( 'roles r', 'u.role = r.id' )
        ->join( 'medias m', 'u.id = m.user_id')
        ->where( 'u.id', $this->session->userdata( 'auth_user' )['id'] );
        $result = $this->db->get();
        if( $result->num_rows() == 1 ){
            return $result->row();
        }
        return FALSE;
    }
}