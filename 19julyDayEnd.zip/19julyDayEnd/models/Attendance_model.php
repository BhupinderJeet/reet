<?php
class Attendance_model extends CI_Model {
	function __construct() {
		parent::__construct();

	}
	public function add_attendance( $data = [] ) {
		if( $data != [] ) {
			$result = $this->db->insert( 'attendance', $data );
			if( $result ) {
				return TRUE;
			}
		}
		return FALSE;
	}
	public function check_old_attendance( $data = [] ) {
		if( $data != [] ) {
			$this->db->where( 'attendance_date', $data['att_date'] )
			->where('course_id', $data['course_id'] )
			->where( 'batch_id', $data['batch_id'] );
			$result = $this->db->get( 'attendance' );
			if( $result->num_rows() > 0 ) {
				return $result->row();
			}
		}
		return FALSE;
	}
	public function get_attendance( $course_id = null, $batch_id = null, $attend_date = null ) {
		if( $data != [] ) {
			$this->db->where( 'attendance_date', $attend_date )
			->where('course_id', $course_id )
			->where( 'batch_id', $batch_id );
			$result = $this->db->get( 'attendance' );
			if( $result->num_rows() > 0 ) {
				return $result->result();
			}
		}
		return FALSE;
	}
	public function update( $data = [] ) {
		if ( isset( $data ) ) {
			$this->db->where( 'id', $data['id'] );
			$result = $this->db->update( 'attendance', $data );
			if( $result ) {
				return TRUE;
			}
		}
		return FALSE;
	}
}