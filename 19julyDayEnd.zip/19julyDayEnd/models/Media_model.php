<?php
class media_model extends CI_Model {
	function __construct() {
		parent::__construct();
	}
	public function add( $data = [] ) {
		if( $data != [] ) {
			$result = $this->db->insert('medias', $data);
			if( $result ) {
				return TRUE;
			}
		}
		return FALSE;
	}
	public function get_my_links( $id = null ) {
		if( $id != null ) {
			$this->db->where( 'user_id', $id );
			$result = $this->db->get('medias');
			if( $result->num_rows() > 0 ) {
				return $result->result();
			}
		}
		return FALSE;
	}
	public function get_all() {
		$this->db->select('m.*, s.name')
		->from('medias m')
		->join('students s', 'm.user_id = s.user_id', 'left' );
		$result = $this->db->get();
		if( $result->num_rows() > 0 ) {
			return $result->result();
		}
		return FALSE;
	}
}