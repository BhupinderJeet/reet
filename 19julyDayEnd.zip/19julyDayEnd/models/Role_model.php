<?php
class Role_model extends CI_Model {
	function __construct() {
		parent::__Construct();
	}
	public function add( $data = [] ) {
		if( $data != [] ) {
			$result = $this->db->insert( 'roles', $data );
			if( $result ) {
				return TRUE;
			}	else {
				return FALSE;
			}
		}
	}
	public function list_roles() {
		$result = $this->db->get('roles');
		if( $result->num_rows() > 0 ) {
			return $result->result();
		}
		return FALSE;
	}
	public function delete( $id = null ){
		if( $id != null ) {
			$this->db->where( 'id', $id );
			$result = $this->db->delete('roles');
			if( $result ) {
				return TRUE;
			}
		}
		return FALSE;
	}
	public function get_role( $id = null ) {
		if( $id != null ) {
			$this->db->where( 'id', $id );
			$res = $this->db->get('roles');
			if( $res->num_rows() > 0 ) {
				return $res->row();
			}
		}
		return FALSE;
	}
	public function edit( $data = [] ) {
		if( $data != [] ) {
			$this->db->where( 'id', $data['id'] );
			$res = $this->db->update( 'roles', $data );
			if( $res ) {
				return TRUE;
			}
		}
		return FALSE;
	}
	public function role_exist( $role = null ) {
		if( $role != null ) {
			$this->db->where( 'id', $role );
			$res = $this->db->get('roles');
			if( $res->num_rows() > 0 ) {
				return TRUE;
			}
		}
		return FALSE;
	}
}