<?php
class Batch_model extends CI_Model {
	function __construct() {
		parent::__construct();
	}
	public function add( $data = [] ) {
		if( isset($data) ) {
			$query = $this->db->insert( 'batches', $data );
			if( $query ) {
				return TRUE;
			}
		}
		return FALSE;
	}
	public function list_batches( $cr_id = null ) {
		if( $cr_id != null ) {
			$this->db->where( 'course_id', $cr_id );
			$query = $this->db->get( 'batches' );
			if( $query->num_rows() > 0 ) {
				return $query->result();
			}	else 	{
				return FALSE;
			}
		}
		return FALSE;
	}
	public function delete( $id = null ) {
		if( $id != null ) {
			$this->db->where( 'id', $id );
			$result = $this->db->delete( 'batches' );
			if( $result ) {
				return TRUE;
			}
			return FALSE;
		}
		return FALSE;
	}
	public function update( $data = [] ) {
		if( $data != [] ) {
			$this->db->where( 'id', $data['id'] );
			$result = $this->db->update( 'batches', $data );
			if( $result ) {
				return TRUE;
			}
			return FALSE;
		}
	}
	public function get_batch( $id = null ) {
		if( $id == null ) {
			return FALSE;
		}
		$this->db->where( 'id', $id );
		$res = $this->db->get( 'batches' );
		if( $res->num_rows() > 0 ) {
			return $res->row();
		}	else {
			return FALSE;
		}
	}
	public function course_batches( $cr_id = null ) {
		if( $cr_id == null ) {
			return FALSE;
		}
		$this->db->where( 'course_id', $cr_id );
		$res = $this->db->get( 'batches' );
		if( $res->num_rows() > 0 ) {
			return $res->result();
		}	
	}
}