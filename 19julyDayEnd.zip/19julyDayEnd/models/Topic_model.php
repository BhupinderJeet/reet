<?php
class Topic_model extends CI_Model {
	function __construct() {
		parent::__construct();
		$this->load->library('session');
	}
	public function add_topic( $data = [] ) {
		if( isset($data) ) {
			$query = $this->db->insert( 'topics', $data );
			if( $query ) {
				return TRUE;
			}
		}
		return FALSE;
	}
	public function list_course_topics( $cr_id = null ) {
		if( $cr_id != null ) {
			$this->db->where( 'course_id', $cr_id );
			$result = $this->db->get( 'topics' );
			if( $result->num_rows() > 0 ) {
				return $result->result();
			}
			return FALSE;
		}
		
	}
	public function delete( $t_id = null ) {
		if( isset( $t_id ) != null ) {
			$this->db->where( 'id', $t_id );
			$result = $this->db->delete('topics');
			if( $result ) {
				return TRUE;
			}
		}
		return FALSE;
	}
	public function edit( $data = [] ) {
		if( isset( $data ) ) {
			$this->db->where( 'id', $data['id'] );
			$result = $this->db->update('topics', $data);
			if( $result ) {
				return TRUE;
			}
			return FALSE;
		}
	}
}