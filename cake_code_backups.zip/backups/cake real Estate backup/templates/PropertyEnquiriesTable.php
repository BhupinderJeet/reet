<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Properties Model
 *
 * @property |\Cake\ORM\Association\BelongsTo $Managers
 *
 * @method \App\Model\Entity\PropertyEnquiry get($primaryKey, $options = [])
 * @method \App\Model\Entity\PropertyEnquiry newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\PropertyEnquiry[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\PropertyEnquiry|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\PropertyEnquiry patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\PropertyEnquiry[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\PropertyEnquiry findOrCreate($search, callable $callback = null, $options = [])
 */
class PropertyEnquiriesTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);
        $this->addBehavior('Acl.Acl', ['controlled']);
        $this->setTable('property_enquiries');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
        
        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Properties', [
            'foreignKey' => 'property_id',
            'joinType' => 'INNER'
        ]);
        
    

    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('contact_no')
            ->maxLength('contact_no', 20)
            ->requirePresence('contact_no', 'create')
            ->notEmpty('contact_no');

        $validator
            ->scalar('email')
            ->maxLength('email', 300)
            ->requirePresence('email', 'create')
            ->notEmpty('email');

        $validator
            ->scalar('message')
            ->maxLength('message', 1000)
            ->requirePresence('message', 'create')
            ->notEmpty('message');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        //$rules->add($rules->existsIn(['manager_id'], 'Managers'));

        return $rules;
    }
}
