<?php
namespace App\Controller;

use App\Controller\AppController;

class HomesController extends AppController {
	public function index(){
    	$this->viewBuilder()->setLayout('homepage');
    }

    public function contact() {
    	$this->viewBuilder()->setLayout('homepage');
    }
    public function loginagent() {
    	$this->viewBuilder()->setLayout('login');
    }
    public function loginclient() {
    	$this->viewBuilder()->setLayout('login');
    }
    public function aboutus() {
        $this->viewBuilder()->setLayout('homepage');
    }
}
?>