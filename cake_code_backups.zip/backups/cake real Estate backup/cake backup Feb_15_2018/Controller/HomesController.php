<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Controller\Controller;
use Cake\Event\Event;
    class HomesController extends AppController {
        public function beforeFilter(Event $event) {
            parent::beforeFilter($event);
            $this->viewBuilder()->setLayout('homepage');

            $this->Auth->allow(['index', 'contact']);
        }
    	public function index(){
        	
        }
        public function contact() {
        	
        }
        public function loginagent() {
        	
        }
        public function loginclient() {
        	
        }
        public function aboutus() {
            
        }
        public function allproperties() {
            $this->loadModel('Properties');       

            $query = $this->Properties->find('all', array(
                'contain' => array('PropertyImages')
                ))->limit(30);
            
            $property = $query->toArray();
            
            //$property = $query->toArray();
            //debug($property);
            $this->set('properties', $property);
        }
        public function viewproperty($id = null) {
            $this->loadModel('Properties');       

            $query = $this->Properties->find('all', array(
                'contain' => array('PropertyImages'),
                'conditions' => ['id' => $id]
                ))->limit(10);
           
            $property = $query->toArray();

            $this->set('property', $property);
        }
        public function contactowner($id = null) {
            $this->loadModel('PropertyEnquiries');
            $property_enquiry = $this->PropertyEnquiries->newEntity();
            if ($this->request->is('post')) {
                $property_enquiry = $this->PropertyEnquiries->patchEntity($property_enquiry, $this->request->getData());
                
                $uid = $this->Auth->User('id');

                //pr($uid); die();
                $property_enquiry->user_id = $uid;
                $property_enquiry->property_id = $id;
                
                if ($this->PropertyEnquiries->save($property_enquiry)) {
                    $this->Flash->success(__('The property enquiry has been saved. The Owner will contact You Soon.'));

                    return $this->redirect(['action' => 'index']);
                }
                $this->Flash->error(__('The property could not be saved. Please, try again.'));
            }

            
            $this->set(compact('property_enquiry'));
        }

        public function searchresult() {
            if($this->request->is('post')) {
                $glo = $this->request->data;
                unset($glo['sort_by']);
                unset($glo['submit']);
               $conditions = [];
                foreach($glo as $key=>$value){
                    if(is_array($value)){
                        if(count($value) > 1){
                            foreach($value as $value1){
                                $conditions["OR"]["$key IN"][] = $value1;
                            }
                        }else{
                            $conditions["OR"]["$key IN"] = $value;
                        }
                    }else{
                        $conditions["OR"][$key] = $value;
                    }
                }
               // pr($conditions);
                $this->loadModel('Properties');       
                
                $query = $this->Paginator->paginate($this->Properties->find('all', array(
                    'contain' => array('PropertyImages'),
                    'conditions' => $conditions
                    ))->limit(10));

                 //pr($query);
                $filter = $query->toArray();
                //pr($filter);
                $this->set('filter', $filter);
            }
        }
        
    }
?>