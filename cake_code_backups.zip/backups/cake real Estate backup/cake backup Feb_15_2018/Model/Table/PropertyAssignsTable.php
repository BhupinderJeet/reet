<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class PropertyAssignsTable extends Table {

	/**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
	public function initialize(array $config)
    {
        parent::initialize($config);
        // $this->addBehavior('Acl.Acl', ['controlled']);
        $this->setTable('property_assigns');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
        
        // $this->belongsTo('Users', [
        //     'foreignKey' => 'user_id',
        //     'joinType' => 'INNER'
        // ]);
        // $this->belongsTo('Properties', [
        //     'foreignKey' => 'property_id',
        //     'joinType' => 'INNER'
        // ]);
        
    

    }


    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        // $validator
        //     ->scalar('assign_from')
        //     // ->maxLength('assign_from', 300)
        //     ->requirePresence('assign_from', 'create')
        //     ->notEmpty('assign_from');

        // $validator
        //     ->scalar('assign_to')
        //     // ->maxLength('assign_to', 300)
        //     ->requirePresence('assign_to', 'create')
        //     ->notEmpty('assign_to');


        return $validator;
    }



    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        //$rules->add($rules->existsIn(['manager_id'], 'Managers'));

        return $rules;
    }
}


?>