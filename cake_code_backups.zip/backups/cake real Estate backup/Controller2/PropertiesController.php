<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Controller\Controller;
use Cake\Event\Event;
/**
 * Properties Controller
 *
 * @property \App\Model\Table\PropertiesTable $Properties
 *
 * @method \App\Model\Entity\Property[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class PropertiesController extends AppController
{

    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        $this->viewBuilder()->setLayout('adminlayout');
        
    }
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        // $properties = $this->paginate($this->Properties);

        // $this->set(compact('properties'));

        $this->loadModel('Properties');       

        $query = $this->Properties->find('all', array(
            'contain' => array('PropertyImages')
            ))->limit(10);
       
        $property = $query->toArray();
        
        //$property = $query->toArray();
        //debug($property);
        $this->set('properties', $property);

        /* Search filter */


        
    }

    /**
     * View method
     *
     * @param string|null $id Property id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        // $property = $this->Properties->get($id, [
        //     'contain' => []
        // ]);

        // $this->set('property', $property);
        $this->loadModel('Properties');       

        $query = $this->Properties->find('all', array(
            'contain' => array('PropertyImages'),
            'conditions' => ['id' => $id]
            ))->limit(10);
       
        $property = $query->toArray();

        //$property = $query->toArray();
        //debug($property);
        $this->set('property', $property);
        
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $this->loadModel('Users');
        $roles = $this->Users->find('list',[
            'conditions' => ['role' => 2],
            'keyField' => 'username',
            'valueField' => 'username'
        ]);
        $property = $this->Properties->newEntity();
        if ($this->request->is('post')) {
            $property = $this->Properties->patchEntity($property, $this->request->getData());
            
            $uid = $this->Auth->User('id');

            //pr($uid); die();
            $property->user_id = $uid;
            //pr($property->toArray()); die();

            if ($this->Properties->save($property)) {
                $this->Flash->success(__('The property has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The property could not be saved. Please, try again.'));
        }
        $this->set('userlist',$roles->toArray());
        $this->set(compact('property'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Property id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $property = $this->Properties->get($id, [
            'contain' => []
        ]);
        $this->loadModel('Users');
        $roles = $this->Users->find('list',[
            'conditions' => ['role' => 2],
            'keyField' => 'id',
            'valueField' => 'username'
        ]);

        if ($this->request->is(['patch', 'post', 'put'])) {
            $property = $this->Properties->patchEntity($property, $this->request->getData());
            if ($this->Properties->save($property)) {
                $this->Flash->success(__('The property has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The property could not be saved. Please, try again.'));
        }
        $this->set('mnlist',$roles->toArray());
        $this->set(compact('property'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Property id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $property = $this->Properties->get($id);
        if ($this->Properties->delete($property)) {
            $this->Flash->success(__('The property has been deleted.'));
        } else {
            $this->Flash->error(__('The property could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function addimages($id = null) {
        $uploadData = '';
        $this->set('uploadData', $uploadData);

        $this->loadModel('Properties');

        $counter =1;
        $this->loadModel('PropertyImages');

        if ($this->request->is('post')) {
            $prop_id = $this->Properties->get($id, [
                'contain' => []
            ]);

            //$property_imgs = $this->PropertyImages->newEntity();

            $property_imgs_all = $this->request->getData();
            //pr($property_imgs_all); die();

            //$property_imgs_all = $this->PropertyImages->newEntities($this->request->data());

            foreach($property_imgs_all as $property_imgs):
    /*  ----------------------------  */
                $property_imgs = $this->PropertyImages->newEntity();

                $property_imgs = $this->PropertyImages->patchEntity($property_imgs, $this->request->getData());

                $target_dir = "img/property/";
                $property_img_n = "property_image" . $counter;
                $target_file = $target_dir . basename($_FILES[$property_img_n]['name']);
                $fName = $_FILES[$property_img_n]['name'];
                $tempName = $_FILES[$property_img_n]['tmp_name'];

                move_uploaded_file($tempName, $target_file);
               
                $property_imgs->property_id = $prop_id['id'];
                $property_imgs->img_url = $target_file;
                
                if ($this->PropertyImages->save($property_imgs)) {
                    $this->Flash->success(__('The user has been saved.'));

                    //return $this->redirect(['action' => 'index']);
                }
                $this->Flash->error(__('The user could not be saved. Please, try again.'));

                $this->set(compact('property_imgs'));
                $counter++;
            endforeach;
        }
        
    /*   --------------------------------  */
    }

    public function listproperties() {
        $properties = $this->paginate($this->Properties);

        $this->set(compact('properties'));
    }


    public function searchresult() {
		if($this->request->is('post')) {
            $glo = $this->request->data;
		   $this->loadModel('Properties');       

			$query = $this->Properties->find('all', array(
				'contain' => array('PropertyImages'),
				'conditions' => ["OR"=>
					['refrence' => $glo['prop_search'],
								'no_of_bedrooms' => $glo['no_bedrooms'],
								'no_of_bathrooms' => $glo['no_bathrooms'],
								'no_of_car_spaces' => $glo['no_carspacess']
								]]
				))->limit(10);
		
        $filter = $query->toArray();
        $this->set('filter', $filter);
    }
}
   
}
