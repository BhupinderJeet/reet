<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Controller\Controller;
use Cake\Event\Event;
    class HomesController extends AppController {
        public function beforeFilter(Event $event) {
            parent::beforeFilter($event);
            $this->viewBuilder()->setLayout('homepage');

            $this->Auth->allow(['index', 'contact']);
        }
    	public function index(){
        	
        }
        public function contact() {
        	
        }
        public function loginagent() {
        	
        }
        public function loginclient() {
        	
        }
        public function aboutus() {
            
        }
        public function allproperties() {
            $this->loadModel('Properties');       

            $query = $this->Properties->find('all', array(
                'contain' => array('PropertyImages')
                ))->limit(30);
            
            $property = $query->toArray();
            
            //$property = $query->toArray();
            //debug($property);
            $this->set('properties', $property);
        }
        public function viewproperty($id = null) {
            $this->loadModel('Properties');       

            $query = $this->Properties->find('all', array(
                'contain' => array('PropertyImages'),
                'conditions' => ['id' => $id]
                ))->limit(10);
           
            $property = $query->toArray();

            $this->set('property', $property);
        }

    }
?>