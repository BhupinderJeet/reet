<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Auth\DefaultPasswordHasher;
use Cake\Event\Event;
use Cake\Controller\Component\FlashComponent;
//use Cake\acl\src\Controller\Component\AclComponent;
/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class UsersController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        $this->Auth->allow(['logout']);
        //$this->addBehavior('Acl.Acl', ['controlled']);
    }

    public function beforeFilter(Event $event) {
        parent::beforeFilter($event);
        $this->viewBuilder()->setLayout('adminlayout');
        $user = $this->Auth->user();
        //$this->Auth->allow();

    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $users = $this->paginate($this->Users);
        // $uv = $users->toArray();
        // for($i = 0; $i<sizeof($uv); $i++) {
        //     $usr = $uv[$i]->toArray();
        //     pr($usr['group_id']);
        // }die;
        $this->set(compact('users'));
    }

    /**
     * View method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $user = $this->Users->get($id, [
            'contain' => []
        ]);

        $this->set('user', $user);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {   

        $this->loadModel('Groups');
        $groups = $this->Groups->find('list', [
            'keyField' => 'id',
            'valueField' => 'name'
        ]);
        //pr($groups->toArray());die;
        $this->set('groups', $groups->toArray());
        $user = $this->Users->newEntity();

        if ($this->request->is('post')) {
            $password = $this->request->data['password'];
            $hasher = new DefaultPasswordHasher();
            $this->request->data['password'] =  $hasher->hash($password);
            $rl = $this->request->data['role'];
            $user->group_id = $rl;

            $user = $this->Users->patchEntity($user, $this->request->getData());
            
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The user could not be saved. Please, try again.'));
        }
        $this->set(compact('user'));
        
    }

    /**
     * Edit method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $user = $this->Users->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The user could not be saved. Please, try again.'));
        }
        $this->set(compact('user'));
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $user = $this->Users->get($id);
        if ($this->Users->delete($user)) {
            $this->Flash->success(__('The user has been deleted.'));
        } else {
            $this->Flash->error(__('The user could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
    public function contacts() {
        
    }
    public function inbox() {
        
    }
    public function tasks() {
        
    }
    public function inspections() {
        
    }
    public function jobs() {
        
    }
    public function properties() {
        
    }

    public function login()
    {
        if ($this->request->is('post')) {
            //pr($this->request->data);
            $user = $this->Auth->identify();
            $user['user_id'] = $user['id'];
            $user['id'] = $user['group_id'];
            if ($user) {
                //pr($user);die;
                $this->Auth->setUser($user);
                return $this->redirect($this->Auth->redirectUrl());
            }
            $this->Flash->error('Your username or password is incorrect.');
        }
        $this->viewBuilder()->setLayout('login');
    }

    

    public function logout()
    {
        $this->Flash->success('You are now logged out.');
        return $this->redirect($this->Auth->logout());
        
    }

    public function addproperty() {
        
    }

    public function selectproperties() {
        
    }
    
    public function adminallproperties() {
        $this->loadModel('Properties');       

        $query = $this->Properties->find('all', array(
            'contain' => array('PropertyImages')
            ))->limit(30);
       
        $property = $query->toArray();
        
        $this->set('properties', $property);
    }

    public function changepassword() {
        
        $user =$this->Users->get($this->Auth->user('id'));
        if (!empty($this->request->data)) {
            $user = $this->Users->patchEntity($user, [
                    'old_password'  => $this->request->data['old_password'],
                    'password'      => $this->request->data['password1'],
                    'password1'     => $this->request->data['password1'],
                    'password2'     => $this->request->data['password2']
                ],
                ['validate' => 'password']
            );
            if ($this->Users->save($user)) {
                $this->Flash->success('The password is successfully changed');
                //return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error('There was an error during the save!');
            }
        }
        $this->set('user',$user);

    }

    public function profile(){
        $us_id = $this->Users->get($this->Auth->user('id'));
        $this->set('userprofile', $us_id);
    }
}
